import java.awt.*;
import javax.swing.*;

public class Engine extends Main{
	
	//40 x 24
	public static Integer screenWidth = 1280;
	public static Integer screenHeight = 720 + 32 - 1;
	
	public static String out = "";
	public static Integer out2 = 0;
	public static Double out3 = 0.0D;
	
	public static Integer fontSize = 14;
	public static String endScreen = "Press space to start";
	
	public static Integer frame = 0;
	public static Integer framerate = 0;
	
	public static Point getMouse(){
		Point m = new Point(MouseInfo.getPointerInfo().getLocation());
		Point s = new Point(f.getLocationOnScreen());
		
		// CHANGE THIS LATER TO MAKE IT WORK
		// - 25 is there to account for the top of the frame
		return new Point(m.x - s.x, (m.y - s.y) - 32);
	}
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setFont(new Font("MONOSPACED", Font.BOLD, fontSize));
		g.setColor(new Color(0, 0, 0));
		g.fillRect(0, 0, screenWidth, screenHeight);
		g.setColor(new Color(255, 255, 255));
		
		Graphics2D g2d = (Graphics2D) g;
		
		//Block.drawBlock(g);
		
		Bullet.drawBullet(g2d);
		
		Player.drawPlayer(g2d);
		
		Enemy.drawEnemy(g2d);
		
		if(gamePhase == 2 || gamePhase == 3 || gamePhase == 4){
			Boss.drawBoss(g2d);
		}
		
		drawCrosshair(g);
		
		/*
		g.drawString(((Integer) framerate).toString(), 0, 14 + 64);
		
		g.drawString(out, 0, 28 + 64);
		
		g.drawString(out2.toString(), 0, 14*3 + 64);
		
		g.drawString(out3.toString(), 0, 14*4 + 64);
		*/
		
		g.drawString(endScreen, screenWidth/2, (screenHeight-1)/2);
		
		frame++;
		
	}
	
	public static void drawCrosshair(Graphics g){
		g.drawImage(Sprite.crosshair, getMouse().x - 16, getMouse().y - 16, Engine.f);
	}
	
	static JFrame f = new JFrame("Scared");
	static JPanel p = new JPanel();
	
	static Engine ex = new Engine();
	
	public static void init(){
		
		f.dispose();
		f.add(ex);
		
		p.setFocusable(true);
		p.requestFocusInWindow();
		f.setSize(new Dimension(screenWidth, screenHeight));
		f.setResizable(true);
		f.setVisible(true);
		f.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	}
}