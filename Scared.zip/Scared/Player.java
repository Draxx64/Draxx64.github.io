import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;

public class Player extends Main{
	
	public static Boolean busy = false;
	public static Boolean canMove = true;
	
	public static Integer x = 0;
	public static Integer y = 0;
	public static Integer speed = 5;
	
	public static Boolean up = false;
	public static Boolean down = false;
	public static Boolean left = false;
	public static Boolean right = false;
	
	public static Integer maxHP = 3;
	public static Integer HP = maxHP;
	
	public static Boolean Invin = false;
	public static Integer InvStop = 0;
	public static Integer ShootStop = 0;
	
	public static Boolean lose = false;
	
	public static Boolean canShoot = true;
	public static Boolean shooting = false;
	public static Integer shootEvery = 5;
	public static Integer frameOffset = 0;
	
	public static String currentShot = "standard";
	public static Integer shotPlace = 0;
	public static ArrayList<String> shotList = new ArrayList<>();
	
	public static void init(){
		lose = false;
		Invin = false;
		x = Engine.screenWidth/2;
		y = (Engine.screenHeight-1)/4*3;
		HP = 3;
		Sprite.player = new ImageIcon(ClassLoader.getSystemResource("Player.png")).getImage();
	}
	
	public static void move(){
		if(Main.frame >= ShootStop && !lose){
			canShoot = true;
			Sprite.player = new ImageIcon(ClassLoader.getSystemResource("canShoot.png")).getImage();
		}
		if(Main.frame >= InvStop && !lose){
			Invin = false;
			Sprite.player = new ImageIcon(ClassLoader.getSystemResource("Player.png")).getImage();
		}
		if(Enemy.Enemies.size() == 0 && gamePhase == 1){
			gamePhase = 2;
			Sprite.enemy = Sprite.arrow;
			Player.HP = Player.maxHP;
		}
		if(canMove){
			Integer angle = (Integer) ((Double) Math.sqrt((speed*speed)/2)).intValue();
			
			if(up && left && !right){
				y -= angle;
				x -= angle;
				return;
			}
			if(up && right && !left){
				y -= angle;
				x += angle;
				return;
			}
			if(down && left && !right){
				y += angle;
				x -= angle;
				return;
			}
			if(down && right && !left){
				y += angle;
				x += angle;
				return;
			}
			
			if(up) y -= speed;
			
			if(down) y += speed;
			
			if(left) x -= speed;
			
			if(right) x += speed;
		}
		
	}
	
	public static void nextShot(boolean dir){
		shotPlace++;
		if(shotPlace >= shotList.size()){
			shotPlace = 0;
		}
		currentShot = shotList.get(shotPlace);
	}
	
	public static void shoot(){
		if(shooting && canShoot){
			if((Main.frame - frameOffset) % shootEvery == 0){
				Point m = Engine.getMouse();
				float rotation = (float) -(Math.atan2(Player.x + 32 - m.x, Player.y + 32 - m.y));
				rotation -= 1.5708F;
				Bullet.genBullet(currentShot, Player.x, Player.y, rotation);
			}
		}
	}
	
	public static void takeDamage(){
		if(!Invin){
			HP -= 1;
			Engine.out = HP.toString();
			Invin = true;
			canShoot = false;
			InvStop = Main.frame + (Main.framerate*3);
			ShootStop = Main.frame + (Main.framerate);
			Sprite.player = new ImageIcon(ClassLoader.getSystemResource("PlayerHurt.png")).getImage();
			if(HP == 0){
				lose = true;
				Sprite.player = new ImageIcon().getImage();
				Engine.fontSize = 32;
				Engine.endScreen = "Game Lost";
			}
		}
	}
	
	public static void rotate(Graphics2D g, boolean rev){
		
		int x = Player.x + 32;
		int y = Player.y + 32;
		
		Point m = Engine.getMouse();
		
		float rotation = (float) -(Math.atan2(x - m.x, y - m.y));
		
		//Engine.out = ((Double) Math.toDegrees(rotation)).toString();
		
		if(!rev){
			g.translate(x, y);
			g.rotate(rotation);
			g.translate(-(x), -(y));
		}
		if(rev){
			g.translate(x, y);
			g.rotate(-rotation);
			g.translate(-(x), -(y));
		}
	}
	
	public static void drawPlayer(Graphics2D g){
		rotate(g, false);
		g.drawImage(Sprite.player, x, y, Engine.f);
		rotate(g, true);
		if(gamePhase != 4){
			for(int i = 0 ; i < maxHP ; i++){
				if(i < HP){
					g.drawImage(Sprite.health, 64*i, 0, Engine.f);
				}
				if(i >= HP){
					g.drawImage(Sprite.losthealth, 64*i, 0, Engine.f);
				}
			}
		}
	}
}