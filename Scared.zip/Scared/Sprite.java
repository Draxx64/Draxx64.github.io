import java.awt.*;
import javax.swing.*;

public class Sprite extends Main{
	public static Image player = new ImageIcon(ClassLoader.getSystemResource("Player.png")).getImage();
	public static Image enemy = new ImageIcon(ClassLoader.getSystemResource("Enemy.png")).getImage();
	public static Image shot = new ImageIcon(ClassLoader.getSystemResource("Shot.png")).getImage();
	public static Image laser = new ImageIcon(ClassLoader.getSystemResource("Laser.png")).getImage();
	public static Image crosshair = new ImageIcon(ClassLoader.getSystemResource("Crosshair.png")).getImage();
	public static Image health = new ImageIcon(ClassLoader.getSystemResource("Health.png")).getImage();
	public static Image losthealth = new ImageIcon(ClassLoader.getSystemResource("LostHealth.png")).getImage();
	public static Image handleft = new ImageIcon(ClassLoader.getSystemResource("HandLeft.png")).getImage();
	public static Image handright = new ImageIcon(ClassLoader.getSystemResource("HandRight.png")).getImage();
	public static Image scared = new ImageIcon(ClassLoader.getSystemResource("Scared.png")).getImage();
	public static Image scared2 = new ImageIcon(ClassLoader.getSystemResource("Scared2.png")).getImage();
	public static Image arrow = new ImageIcon(ClassLoader.getSystemResource("Arrow.png")).getImage();
	public static Image end = new ImageIcon(ClassLoader.getSystemResource("theEnd.png")).getImage(); 
}