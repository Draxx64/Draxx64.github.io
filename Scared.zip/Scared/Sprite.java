import java.awt.*;
import javax.swing.*;

public class Sprite extends Main{
	public static Image player = getArt("Player");
	public static Image enemy = getArt("Enemy");
	public static Image shot = getArt("Shot");
	public static Image laser = getArt("Laser");
	public static Image crosshair = getArt("Crosshair");
	public static Image health = getArt("Health");
	public static Image losthealth = getArt("LostHealth");
	public static Image handleft = getArt("HandLeft");
	public static Image handright = getArt("HandRight");
	public static Image scared = getArt("Scared");
	public static Image scared2 = getArt("Scared2");
	public static Image arrow = getArt("Arrow");
	public static Image end = getArt("theEnd");
	
	public static Image getArt(String name){
		return new ImageIcon(ClassLoader.getSystemResource("").getPath().split(".bin/")[0] + "Art/" + name + ".png").getImage();
	}
	
	public static String getPath(String name){
		return ClassLoader.getSystemResource("").getPath().split(".bin/")[0] + "Art/" + name + ".png";
	}
	
}