import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Random;

public class Boss extends Main{
	
	public static Boolean inPos = false;
	
	public static Integer x = Engine.screenWidth/2 - 32*5;
	public static Double y = -340D;
	public static Double hBob = 1D;
	
	public static Double LHx = (double) Engine.screenWidth/4 - 32*6;
	public static Double LHy = -250D;
	public static Double LHBob = 0D;
	
	public static Double RHx = (double) Engine.screenWidth/4*3 - 32*6;
	public static Double RHy = -250D;
	public static Double RHBob = 180D;
	
	public static Integer MaxHealth = 150;
	public static Integer Health = MaxHealth;
	
	public static Integer startEvent = 0;
	public static Integer changeEvent = 0;
	
	public static Integer SpawnRate = 10;
	public static Integer SpawnAmount = 5;
	
	public static Random rand = new Random();
	
	public static void move(){
		
		if(!inPos){
			int am = 1;
			y += am;
			LHy += am;
			RHy += am;
			if(y > -90D){
				y = -90D;
				inPos = true;
			}
		}
		
		if(inPos){
			Event();
		}
		
		if(inPos){
			y += Math.sin(Math.toRadians(hBob))/2;
			if(hBob < 360){
				hBob += 1;
			}
			else{
				hBob = 1D;
			}
		}
		
		LHx += Math.cos(Math.toRadians(LHBob));
		LHy += Math.sin(Math.toRadians(LHBob));
		if(LHBob > 0){
			LHBob -= 3;
		}
		else{
			LHBob = 360D;
		}
		
		RHx += Math.cos(Math.toRadians(RHBob));
		RHy += Math.sin(Math.toRadians(RHBob));
		if(RHBob < 360){
			RHBob += 3;
		}
		else{
			RHBob = 0D;
		}
		
	}
	
	public static void Event(){
		if(gamePhase == 3 && Enemy.Enemies.size() < 3){
			startEvent = 0;
		}
		if(changeEvent <= Main.frame){
			if(gamePhase == 2){
				Sprite.scared = new ImageIcon(ClassLoader.getSystemResource("Scared.png")).getImage();
			}
			if(gamePhase == 3){
				Sprite.scared = Sprite.scared2;
			}
		}
		if(startEvent <= Main.frame){
			changeEvent = Main.frame + 60;
			startEvent = Main.frame + 60*SpawnRate;
			if(gamePhase == 2){
				Sprite.scared = Sprite.scared2;
			}
			if(gamePhase == 3){
				Sprite.scared = new ImageIcon(ClassLoader.getSystemResource("Scared.png")).getImage();
			}
			if(gamePhase != 4){
				EventSpawnEnemies();
			}
		}
	}
	
	public static void EventSpawnEnemies(){
		int hand = rand.nextInt(2);
		int u = SpawnAmount;
		if(hand == 0){
			while(u > 0){
				Enemy.genEnemy(LHx + 176, LHy + 104);
			u--;
			}
		}
		if(hand == 1){
			while(u > 0){
				Enemy.genEnemy(RHx + 208, RHy + 280);
			u--;
			}
		}
	}
	
	public static void collide(){
		ArrayList<Bullet> Delete = new ArrayList<>();
		for(Bullet b : Bullet.Bullets){
			Boolean hit = false;
			Double bx = b.x + 16;
			Double by = b.y + 16;
			Double ex = (Double) x.doubleValue();
			Double ey = (Double) y;
			
			int num = 64 - 16 - 16;
			
			int x1 = 64;
			int y1 = 64;
			int x2 = 64*3 + x1;
			int y2 = 64*2 + 32 + y1;
			if((isBet(bx, ex + x1, ex + x2) || isBet(bx + num, ex + x1, ex + x2)) && (isBet(by, ey + y1, ey + y2) || isBet(by + num, ey + y1, ey + y2))){
			 	hit = true;
			}
			x1 = 80;
			y1 = 64*3 + 32;
			x2 = 160 + x1;
			y2 = 32 + y1;
			if((isBet(bx, ex + x1, ex + x2) || isBet(bx + num, ex + x1, ex + x2)) && (isBet(by, ey + y1, ey + y2) || isBet(by + num, ey + y1, ey + y2))){
			 	hit = true;
			}
			
			if(hit){
				Delete.add(b);
				Health--;
				if(Health <= 0 && gamePhase == 2){
					MaxHealth = 250;
					Health = MaxHealth;
					Enemy.Enemies.clear();
					Sprite.scared = Sprite.scared2;
					SpawnAmount = 5;
					SpawnRate = 5;
					Player.HP = Player.maxHP;
					gamePhase = 3;
				}
				if(Health <= 0 && gamePhase == 3){
					gamePhase = 4;
					Health = MaxHealth;
					y = -90D;
					hBob = 0D;
					Enemy.Enemies.clear();
					Sprite.scared = Sprite.end;
					Engine.endScreen = "";
				}
			}
		}
		Bullet.Bullets.removeAll(Delete);
		
		/*
		for(Enemy e : Enemies){
			Double px = Double.valueOf(Player.x.toString());
			Double py = Double.valueOf(Player.y.toString());
			Double ex = e.x;
			Double ey = e.y;
			if((isBet(ex, px, px + 33) || isBet(ex + 64, px + 31, px + 64)) && (isBet(ey, py, py + 33) || isBet(ey + 64, py + 31, py + 64))){
				Player.takeDamage();
			}
		}
		*/
	}
	
	public static void drawHealth(Graphics2D g){
		if(gamePhase != 4){
			g.setColor(new Color(255, 0, 0));
			g.fill(new Rectangle(
				Engine.screenWidth/2 - 250, Engine.screenHeight - 128,
				500, 32
				));
			g.setColor(new Color(0, 255, 0));
			Double aids1 = new Double(MaxHealth);
			Double aids2 = new Double(Health);
			Double CancerAids = 500/aids1*aids2;
			Integer AidsCancerusMaximus = ((Long) Math.round(CancerAids)).intValue();
			g.fill(new Rectangle(
				Engine.screenWidth/2 - 250, Engine.screenHeight - 128,
				AidsCancerusMaximus,
				32
			));
		}
	}
	
	public static void drawBoss(Graphics2D g){
		drawHealth(g);
		int multi = 5;
		g.drawImage(Sprite.scared, x, (int) y.doubleValue(), 64*multi, 64*multi, Engine.f);
		multi = 6;
		if(gamePhase != 4){
			g.drawImage(Sprite.handleft, (int) LHx.doubleValue(), (int) LHy.doubleValue(), 64*multi, 64*multi, Engine.f);
			g.drawImage(Sprite.handright, (int) RHx.doubleValue(), (int) RHy.doubleValue(), 64*multi, 64*multi, Engine.f);
		}
	}
	
}