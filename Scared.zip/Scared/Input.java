import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Input extends Main{
	
	public static String focus = "PLAYER";
	
	public static void init(){
		Engine.f.addKeyListener(new KeyListener(){
			@Override
			public void keyPressed(KeyEvent e){
				int key = e.getKeyCode();
				
				if(key == KeyEvent.VK_ESCAPE){
					System.exit(3);
				}
				
				if(focus == "MENU"){
					if(key == KeyEvent.VK_W){
						//Menu.chgMenu(false);
					}
					if(key == KeyEvent.VK_S){
						//Menu.chgMenu(true);
					}
					if(key == KeyEvent.VK_SPACE){
						//Menu.select();
						return;
					}
				}
				
				if(gamePhase == 0){
					if(key == KeyEvent.VK_SPACE){
						gamePhase = 1;
						Engine.endScreen = "";
					}
				}
				
				if(Player.lose){
					if(key == KeyEvent.VK_SPACE){
						ClassLoader restart = Main.class.getClassLoader();
						System.out.print("Attempt: ");
						try{
							Class aClass = restart.loadClass("Main");
							System.out.println("Success!");
						}
						catch(ClassNotFoundException CNFEX){
							System.out.println("Failiure...");
							CNFEX.printStackTrace();
						}
						System.exit(2);
					}
				}
				
				if(focus == "PLAYER" && !Player.lose){
					
					if(key == KeyEvent.VK_P){
						Enemy.Enemies.get(0).x = 500D;
						Enemy.Enemies.get(0).y = 350D;
					}
					if(key == KeyEvent.VK_O){
						Enemy.canMove = !Enemy.canMove;
					}
					
					if(key == KeyEvent.VK_W){
						Player.up = true;
					}
					if(key == KeyEvent.VK_S){
						Player.down = true;
					}
					if(key == KeyEvent.VK_A){
						Player.left = true;
					}
					if(key == KeyEvent.VK_D){
						Player.right = true;
					}
					
					if(key == KeyEvent.VK_E){
						Player.nextShot(true);
						Player.frameOffset = Main.frame % Bullet.basedBullet();
					}
					if(key == KeyEvent.VK_Q){
						Player.nextShot(false);
						Player.frameOffset = Main.frame % Bullet.basedBullet();
					}
					
					if(key == KeyEvent.VK_RIGHT){
					}
					if(key == KeyEvent.VK_LEFT){
					}
					if(key == KeyEvent.VK_DOWN){
					}
					if(key == KeyEvent.VK_UP){
					}
					
				}
				
			}
			@Override
			public void keyReleased(KeyEvent e){
				int key = e.getKeyCode();
				
				if(key == KeyEvent.VK_W){
					Player.up = false;
				}
				if(key == KeyEvent.VK_S){
					Player.down = false;
				}
				if(key == KeyEvent.VK_A){
					Player.left = false;
				}
				if(key == KeyEvent.VK_D){
					Player.right = false;
				}
				
			}
			@Override
			public void keyTyped(KeyEvent e){
				int key = e.getKeyCode();
				
			}
		});
		
		Engine.f.addMouseListener(new MouseAdapter(){
			@Override
			public void mousePressed(MouseEvent e){
				//left click
				if(e.getButton() == MouseEvent.BUTTON1 && !Player.lose){
					try{
						Player.shooting = true;
						Player.frameOffset = Main.frame % Bullet.basedBullet();
					}
					catch(NullPointerException npe){
						System.out.println("press error");
					}
				}
				//right click
				if(e.getButton() == MouseEvent.BUTTON3){
					try{
						
					}
					catch(NullPointerException npe){
					}
				}
				//middle click
				if(e.getButton() == MouseEvent.BUTTON2){
				}
			}
			
			@Override
			public void mouseReleased(MouseEvent e){
				//left click
				if(e.getButton() == MouseEvent.BUTTON1){
					try{
						Player.shooting = false;
					}
					catch(NullPointerException npe){
						System.out.println("release error");
					}
				}
				//right click
				if(e.getButton() == MouseEvent.BUTTON3){
					try{
						
					}
					catch(NullPointerException npe){
					}
				}
				//middle click
				if(e.getButton() == MouseEvent.BUTTON2){
				}
			}
		});
		
	}
}