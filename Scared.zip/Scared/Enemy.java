import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Random;

public class Enemy extends Main{
	
	public static ArrayList<Enemy> Enemies = new ArrayList<>();
	
	//how fast
	public static Integer speedCap = 10;
	//how slippery
	public static Double accel = 10D;
	//accuracy
	public static Double accur = 5D;
	
	public static Integer maxHealth = 5;
	
	public static Boolean canMove = true;
	
	public static Random rand = new Random();
	
	public static void init(){
		Enemies.clear();
		int u = 10;
		while(u > 0){
			int t = rand.nextInt(2);
			if(t == 1){
				Enemy.genEnemy(Engine.screenWidth, Engine.screenHeight/4);
			}
			if(t == 0){
				Enemy.genEnemy(0, Engine.screenHeight/4);
			}
			u--;
		}
	}
	
	public void move(){
		spriteRot = -(Math.atan2(Player.x - x, Player.y - y));
		
		Double rot = Math.atan2(Player.x - x, Player.y - y);
		
		if(rand.nextInt(2) == 0){
			int temp = rand.nextInt(4);
			int mag = rand.nextInt(100) + 1;
			switch(temp){
				case 0:
					rot = Math.atan2(Player.x - x, Player.y - y);
					break;
				case 1:
					rot = Math.atan2((x - Player.x)*mag, Player.y - y);
					break;
				case 2:
					rot = Math.atan2(Player.x - x, (y - Player.y)*mag);
					break;
				case 3:
					rot = Math.atan2((x - Player.x)*mag, (y - Player.y)*mag);
					break;
			}
		}
		if(rand.nextInt(60*5) == 0){
			int r = rand.nextInt(7) - 3;
			while(r == 0){
				r = rand.nextInt(7) - 3;
			}
			rot *= r;
		}
		
		if(canMove){
			
			if(Main.Difficulty.equals("hard")){
				accur = new Double(Main.frame)/60/10 + 5;
				
				if(accel > 1){
					accel = 10 - new Double(Main.frame)/60/20;
				}
			}
			
			dx += ((Math.cos(rot - 1.5708F))/accel)*accur;
			dy += ((Math.sin(rot - 1.5708F))/accel)*accur;
			
			while(Math.sqrt(dx*dx + dy*dy) > speedCap){
				dx -= dx/100;
				dy -= dy/100;
			}
			
			x += dx;
			y -= dy;
		}
	}
	
	public static void collide(){
		ArrayList<Bullet> Delete = new ArrayList<>();
		ArrayList<Enemy> DeleteE = new ArrayList<>();
		for(Enemy e : Enemies){
			for(Bullet b : Bullet.Bullets){
				Double bx = b.x;
				Double by = b.y;
				Double ex = e.x;
				Double ey = e.y;
				if((isBet(ex, bx, bx + 64) || isBet(ex + 64, bx, bx + 64)) && (isBet(ey, by, by + 64) || isBet(ey + 64, by, by + 64))){
					Delete.add(b);
					e.health--;
					if(e.health <= 0){
						DeleteE.add(e);
					}
				}
			}
		}
		Bullet.Bullets.removeAll(Delete);
		Enemies.removeAll(DeleteE);
		for(Enemy e : Enemies){
			Double px = Double.valueOf(Player.x.toString());
			Double py = Double.valueOf(Player.y.toString());
			Double ex = e.x;
			Double ey = e.y;
			if((isBet(ex, px, px + 33) || isBet(ex + 64, px + 31, px + 64)) && (isBet(ey, py, py + 33) || isBet(ey + 64, py + 31, py + 64))){
				Player.takeDamage();
			}
		}
	}
	
	public static void drawHealth(Graphics2D g, Enemy e){
		g.setColor(new Color(255, 0, 0));
		g.fill(new Rectangle(
			round(e.x - 8),
			round(e.y - 32),
			64 + 16,
			16
			));
		g.setColor(new Color(0, 255, 0));
		Double aids1 = new Double(maxHealth);
		Double aids2 = new Double(e.health);
		Double CancerAids = 80/aids1*aids2;
		Integer AidsCancerusMaximus = ((Long) Math.round(CancerAids)).intValue();
		g.fill(new Rectangle(
			round(e.x - 8),
			round(e.y - 32),
			AidsCancerusMaximus,
			16
		));
	}
	
	public void rotate(Graphics2D g, Double rot, boolean rev){
		if(!rev){
			g.translate(this.x + 32, this.y + 32);
			g.rotate(rot + 1.5708F*2);
			g.translate(-(this.x + 32), -(this.y + 32));
		}
		if(rev){
			g.translate(this.x + 32, this.y + 32);
			g.rotate(-rot + 1.5708F*2);
			g.translate(-(this.x + 32), -(this.y + 32));
		}
	}
	
	public static void drawEnemy(Graphics2D g){
		for(Enemy e : Enemies){
			drawHealth(g, e);
			
			e.rotate(g, e.spriteRot, false);
			g.drawImage(Sprite.enemy, round(e.x), round(e.y), Engine.f);
			e.rotate(g, e.spriteRot, true);
			
		}
	}
	
	public Integer health = maxHealth;
	
	public Double x;
	public Double y;
	public Double dx = 0D;
	public Double dy = 0D;
	public Double spriteRot;
	
	public static void genEnemy(double x, double y){
		Enemies.add(new Enemy(x, y));
	}
	
	public Enemy(double x, double y){
		this.x = x;
		this.y = y;
		this.spriteRot = -(Math.atan2(Player.x - this.x, Player.y - this.y));
	}
	
	public Enemy(){}
	
}