import java.awt.*;
import javax.swing.*;

public class Main extends JPanel{
	
	public static final Integer framerate = 60;
	
	public static Integer frame = 0;
	
	public static void main(String[] args){
		
		Engine.init();
		
		System.out.println("It's raining");
		
		for(int i = 0 ; i < 30 ; i++){
			Rain.move();
		}
		
		while(true){
			try{Thread.sleep(1000/framerate);} catch(InterruptedException e){}
			
			Rain.move();
			
			try{
				Engine.ex.repaint();
			}
			catch(java.util.ConcurrentModificationException e){
				System.out.println("Modification");
			}
			
			frame++;
			
		}
	}
}