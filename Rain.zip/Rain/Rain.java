import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Random;
import javax.imageio.ImageIO;
import java.io.IOException;

public class Rain extends Main{
	
	public static Random rand = new Random();
	
	public static ArrayList<Rain> List = new ArrayList<>();
	
	public Double x = 0D;
	public Double y = 0D;
	
	public static Double offSet = Math.tan(Math.toRadians(Engine.Rotation))*Engine.screenHeight;
	
	public static void move(){
		int wid = Engine.f.getSize().width;
		int hei = Engine.f.getSize().height;
		if(Engine.screenWidth != wid){
			Engine.screenWidth = wid;
		}
		if(Engine.screenHeight != hei){
			Engine.screenHeight = hei;
		}
		int temp = rand.nextInt(3) + 1;
		while(temp > 0){
			temp--;
			new Rain(rand.nextInt(Engine.screenWidth + offSet.intValue()) - offSet.intValue());
		}
		ArrayList<Rain> del = new ArrayList<>();
		for(Rain r : List){
			r.y += 4;
			if(r.y > Engine.screenHeight + offSet + 32){
				del.add(r);
			}
		}
		List.removeAll(del);
	}
	
	public static void drawRain(Graphics g){
		for(Rain r : List){
			// try{
				g.drawImage(new ImageIcon(ClassLoader.getSystemResource("").getPath().split(".bin/")[0] + "Art/Rain.png").getImage(), r.x.intValue(), r.y.intValue(), Engine.f);
			// }
			// catch(java.io.IOException IOEX){
			// }
		}
	}
	
	public Rain(Integer x){
		this.x = (Double) x.doubleValue();
		this.y = 0D;
		List.add(this);
	}
	
	public Rain(){}
}