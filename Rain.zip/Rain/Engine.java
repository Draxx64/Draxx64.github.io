import java.awt.*;
import javax.swing.*;

public class Engine extends Main{
	
	public static Double Rotation = 10D;
	
	public static Integer screenWidth = 640;
	public static Integer screenHeight = 640;
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setColor(new Color(0, 0, 0));
		g.fillRect(0, 0, screenWidth, screenHeight);
		Graphics2D g2d = (Graphics2D) g;
		g2d.rotate(Math.toRadians(-(Rotation)));
		
		try{
		Rain.drawRain(g);
		}
		catch(java.util.ConcurrentModificationException CMEX){
		}
	}
	
	static JFrame f = new JFrame("Rain");
	static JPanel p = new JPanel();
	
	static Engine ex = new Engine();
	
	public static void init(){
		
		f.dispose();
		f.add(ex);
		
		p.setFocusable(true);
		p.requestFocusInWindow();
		f.setSize(new Dimension(screenWidth, screenHeight));
		f.setResizable(true);
		f.setVisible(true);
		f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
}