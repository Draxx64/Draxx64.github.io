import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;

class Input extends Main{
	
	public static void init(){
		Engine.f.addKeyListener(new KeyListener(){
			@Override
			public void keyPressed(KeyEvent e){
				int key = e.getKeyCode();
				
				if(key == KeyEvent.VK_ESCAPE){
					System.exit(1);
				}
				
				if(key == KeyEvent.VK_J){
					Spew = true;
					Stuff.SpewsLeft = numSpews;
				}
				
				if(key == KeyEvent.VK_Q){
					spewNum--;
				}
				if(key == KeyEvent.VK_W){
					spewNum++;
				}
				
				if(key == KeyEvent.VK_A){
					spewSpeed--;
				}
				if(key == KeyEvent.VK_S){
					spewSpeed++;
				}
				
				if(key == KeyEvent.VK_Z){
					numSpews--;
				}
				if(key == KeyEvent.VK_X){
					numSpews++;
				}
				
				if(key == KeyEvent.VK_F){
					spewLag--;
					if(spewLag <= 0){
						spewLag = 1;
					}
				}
				if(key == KeyEvent.VK_G){
					spewLag++;
				}
			}
			@Override
			public void keyReleased(KeyEvent e){
				int key = e.getKeyCode();
				
			}
			@Override
			public void keyTyped(KeyEvent e){
			}
		});
	}
}