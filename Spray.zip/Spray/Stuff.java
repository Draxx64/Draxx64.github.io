import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Random;

public class Stuff extends Main{
	
	public static Random rand = new Random();
	
	public String type = "Water";
	
	public Integer x = 40;
	public Integer y = 320;
	
	public Double nx = 0D;
	public Double ny = 0D;
	public Double grav = 0.2D;
	
	public Double speed = 0D;
	public Double angle = 0D;
	
	public static Image Water = getArt("Water");
	public static Image Blood = getArt("Water");
	
	public static ArrayList<Stuff> List = new ArrayList<>();
	
	public static ArrayList<Stuff> Del = new ArrayList<>();
	
	public static void drawStuff(Graphics g){
		for(Stuff s : List){
			switch(s.type){
				case "Water":
					g.drawImage(Water, s.x, s.y, Engine.f);
					break;
				case "Blood":
					g.drawImage(Blood, s.x, s.y, Engine.f);
					break;
			}
		}
	}
	
	public static Integer SpewsLeft = 0;
	
	public static void move(){
		if(Spew){
			if(frame % spewLag == 0){
				SpewsLeft--;
				Stuff.makeSpew(spewNum, "Water");
				if(SpewsLeft <= 0){
					Spew = false;
				}
			}
		}
		Del.clear();
		try{
			for(Stuff s : List){
				s.update();
			}
		}
		catch(java.util.ConcurrentModificationException CMEX){
			System.out.println("mod move");
		}
		List.removeAll(Del);
	}
	
	public void update(){
		y += ny.intValue();
		x += nx.intValue();
		nx -= nx/300D;
		ny += grav;
		
		if(x > 640 || x < 0 || y > 640){
			Del.add(this);
		}
	}
	
	public static void makeSpew(int num, String type){
		for(int i = 0 ; i < num ; i++){
			List.add(new Stuff(type));
		}
	}
	
	public Stuff(String type){
		this.type = type;
		
		//this.x = this.x + (rand.nextInt(21) - 10);
		//this.y = this.y + (rand.nextInt(21) - 10);
		
		this.speed = rand.nextDouble()*8D + spewSpeed.doubleValue();
		System.out.println(this.speed);
		this.angle = ((Integer) (rand.nextInt(50) + 20)).doubleValue();
		
		this.nx = Math.cos(Math.toRadians(this.angle))*this.speed;
		this.ny = -(Math.sin(Math.toRadians(this.angle))*this.speed);
		
	}
	
	public Stuff(){}
	
}