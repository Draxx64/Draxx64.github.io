import java.awt.*;
import javax.swing.*;

public class Engine extends Main{
	
	//40 x 24
	public static Integer screenWidth = 640;
	public static Integer screenHeight = 640;
	
	public static String out1 = "";
	
	public static Integer frame = 0;
	public static Integer framerate = 0;
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setFont(new Font("MONOSPACED", Font.BOLD, 14));
		g.setColor(new Color(0, 0, 0));
		
		Graphics2D g2d = (Graphics2D) g;
		
		try{
			Stuff.drawStuff(g);
		}
		catch(java.util.ConcurrentModificationException CMEX){
			System.out.println("mod draw");
		}
		
		g.drawString(((Integer) framerate).toString(), 0, 14);
		
		frame++;
		
		g.drawString(Main.frame.toString(), 0, 28);
		
		//public static Integer spewSpeed = 3;
		//public static Integer numSpews = 6;
		//public static Integer spewLag = 10;
		
		g.drawString("Number of projectiles: " + spewNum.toString(), 0, 14*3);
		g.drawString("Projectile speed: " + spewSpeed.toString(), 0, 14*4);
		g.drawString("Number of spews: " + numSpews.toString(), 0, 14*5);
		g.drawString("Time between spews: " + spewLag.toString(), 0, 14*6);
		
	}
	
	static JFrame f = new JFrame("Physics Test");
	static JPanel p = new JPanel();
	
	static Engine ex = new Engine();
	
	public static void init(){
		
		f.dispose();
		f.add(ex);
		
		p.setFocusable(true);
		p.requestFocusInWindow();
		f.setSize(new Dimension(screenWidth, screenHeight));
		f.setResizable(true);
		f.setVisible(true);
		f.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	}
}