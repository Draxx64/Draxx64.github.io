import java.awt.*;
import javax.swing.*;

public class Main extends JPanel{
	
	public static final Integer framerate = 60;
	
	public static Integer frame = 0;
	
	public static Boolean Spew = false;
	public static Integer spewNum = 5;
	public static Integer spewSpeed = 3;
	public static Integer numSpews = 5;
	public static Integer spewLag = 5;
	
	public static Image getArt(String name){
		return new ImageIcon(ClassLoader.getSystemResource("").getPath().split(".bin/")[0] + "Art/" + name + ".png").getImage();
	}
	
	public static String getPath(String name){
		return ClassLoader.getSystemResource("").getPath().split(".bin/")[0] + "Art/" + name + ".png";
	}
	
	public static void main(String[] args) throws InterruptedException{
		System.out.println("Starting");
		
		Engine.init();
		Input.init();
		
		System.out.println("Started\n|");
		
		while(true){
			Thread.sleep(1000/framerate);
			
			Stuff.move();
			
			try{
				Engine.ex.repaint();
			}
			catch(java.util.ConcurrentModificationException e){
				System.out.println("Modification");
			}
			
			frame++;
			
			if(frame % framerate == 0){
				Engine.framerate = Engine.frame;
				Engine.frame = 0;
			}
		}
	}
}