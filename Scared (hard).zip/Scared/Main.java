import java.awt.*;
import javax.swing.*;

public class Main extends JPanel{
	
	public static final Integer framerate = 60;
	
	public static Integer frame = 0;
	
	public static Integer gamePhase = 0;
	
	public static String getPath(String s){
		return ClassLoader.getSystemResource("").getPath().split(".bin/")[0] + s;
	}
	
	public static boolean isBet(int num, int start, int stop){
		//System.out.println(start + ", " + num + ", " + stop + ", " + (num >= start && num <= stop));
		return num >= start && num <= stop;
	}
	
	public static boolean isBet(double num, double start, double stop){
		//System.out.println(start + ", " + num + ", " + stop + ", " + (num >= start && num <= stop));
		return num >= start && num <= stop;
	}
	
	public static Integer dif(int x, int y){
		return Math.abs(x - y);
	}
	
	public static Double dif(Double x, Double y){
		return Math.abs(x - y);
	}
	
	public static Integer round(Double value){
		return value.intValue();
	}
	
	public static String Difficulty = "hard";
	
	public static void main(String[] args){
		
		Init.init();
		
		while(true){
			try{Thread.sleep(1000/framerate);} catch(InterruptedException e){}
			
			if(gamePhase > 0){
				Player.move();
				
				Player.shoot();
				
				Bullet.move();
				
				for(Enemy e : Enemy.Enemies){
					e.move();
				}
				
				Enemy.collide();
			}
			
			if(gamePhase == 2){
				Boss.move();
				Boss.collide();
			}
			
			if(gamePhase == 3){
				Boss.move();
				Boss.collide();
			}
			
			if(gamePhase == 4){
				Boss.move();
			}
			
			try{
				Engine.ex.repaint();
			}
			catch(java.util.ConcurrentModificationException e){
				System.out.println("Modification");
			}
			
			frame++;
			
			if(frame % framerate == 0){
				Engine.framerate = Engine.frame;
				Engine.frame = 0;
			}
		}
	}
}