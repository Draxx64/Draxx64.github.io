public class Init extends Main{
	
	public static void init(){
		System.out.println("STARTUP");
		
		System.out.println("INPUT");
		Input.init();
		
		System.out.println("PLAYER");
		Player.init();
		
		//System.out.println("SPRITES");
		//Sprite.init();
		
		//System.out.println("BLOCKS");
		//Block.init();
		
		//System.out.println("SCRIPT");
		//Script.init();
		
		//System.out.println("LEVEL");
		//Levels.init();
		
		System.out.println("ENGINE");
		Engine.init();
		
		System.out.println("FINISHED STARTUP\nINITIALIZING");
		
		System.out.println("ENEMY");
		Enemy.init();
		
		System.out.println("STARTED\n|");
		
	}
}