import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Random;

public class Bullet extends Player{
	
	public static ArrayList<Bullet> Bullets = new ArrayList<>();
	
	public static Random rand = new Random();
	
	public static Integer round(Double value){
		return value.intValue();
	}
	
	public static Integer basedBullet(){
		String temper = Player.currentShot;
		switch(temper){
			case "standard":
				return 3;
			case "lazer":
				return 5;
		}
		System.out.println("fuck");
		return null;
	}
	
	public static void move(){
		ArrayList<Bullet> Delete = new ArrayList<>();
		for(Bullet b : Bullets){
			b.x += Math.cos(b.rotation)*b.shootspeed;
			b.y += Math.sin(b.rotation)*b.shootspeed;
			if(b.x < 0 || b.x > Engine.screenWidth || b.y < 0 || b.y > Engine.screenHeight){
				Delete.add(b);
			}
		}
		Bullets.removeAll(Delete);
	}
	
	public static void rotate(Graphics2D g, Bullet b, boolean rev){
		if(!rev){
			g.translate(b.x + 32, b.y + 32);
			g.rotate(b.rotation + 1.5708F);
			g.translate(-(b.x + 32), -(b.y + 32));
		}
		if(rev){
			g.translate(b.x + 32, b.y + 32);
			g.rotate(-b.rotation - 1.5708F);
			g.translate(-(b.x + 32), -(b.y + 32));
		}
	}
	
	public static void drawBullet(Graphics2D g){
		try{
			Image tempImg = Sprite.shot;
			for(Bullet b : Bullets){
				rotate(g, b, false);
				
				switch(b.name){
					case "standard":
						tempImg = Sprite.shot;
						break;
						
					case "lazer":
						tempImg = Sprite.laser;
						break;
				}
				
				g.drawImage(tempImg, round(b.x), round(b.y), Engine.f);
				rotate(g, b, true);
			}
		}
		catch(java.util.ConcurrentModificationException e){
			System.out.println("Bullet");
		}
	}
	
	public String name;
	public Double x;
	public Double y;
	//standard: 15
	public Integer shootspeed;
	public float rotation;
	
	public static void genBullet(String name, double x, double y, float rotation){
		
		/*
		x += (rand.nextInt(magnitude) + 1)*signX + Math.cos(rotation)*40;
		y += (rand.nextInt(magnitude) + 1)*signY + Math.sin(rotation)*40;
		*/
		
		if(name == "standard"){
			int magnitude = 3;
			int signX = 1;
			int signY = 1;
			if(rand.nextInt(2) == 0){
				signX = -1;
			}
			if(rand.nextInt(2) == 0){
				signY = -1;
			}
			
			x += Math.cos(rotation)*40 + Math.sin(rotation)*magnitude*signX;
			y += Math.sin(rotation)*40 + Math.cos(rotation)*magnitude*signY;
		}
		
		int tempshootspeed = 5;
		
		switch(name){
			case "standard":
				tempshootspeed = 15;
				break;
				
			case "lazer":
				tempshootspeed = 100;
				break;
				
		}
		
		Bullets.add(new Bullet(name, x, y, tempshootspeed, rotation));
	}
	
	public Bullet(String name, double x, double y, int shootspeed, float rotation){
		this.name = name;
		this.x = x;
		this.y = y;
		this.shootspeed = shootspeed;
		this.rotation = rotation;
	}
	
	public Bullet(){}
	
}