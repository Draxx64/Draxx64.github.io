import java.awt.*;
import javax.swing.*;
import java.util.Random;

public class Main extends JPanel{
	
	public static Integer fps = 30;
	public static Integer wfps = 1000/fps;
	public static Integer frames = 0;
	public static String GameState = "MENU";
	
	public static Random rand = new Random();
	public static Integer lvls = 3;
	
	public static int randInt(int max){
		return rand.nextInt(max);
	}
	
	public static void main(String[] args){
		Init.INIT();
		Input.focus = "MENU";
		Menu.openMenu("MainMenu");
		while(true){
			try{Thread.sleep(wfps);} catch(InterruptedException e){}
			Engine.ex.repaint();
			
			if(GameState == "MENU"){
			}
			if(GameState == "SWIT"){
				Slidey.Move();
			}
			
			
			frames++;
		}
	}
}