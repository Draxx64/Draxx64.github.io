import java.util.ArrayList;
import java.awt.*;
import javax.swing.*;

public class Menu extends Main{
	
	public static boolean Shown = true;
	
	public static Integer Opt = 0;
	
	public String id = "";
	
	public static String currMenu = "";
	
	public static ArrayList<Menu> Master = new ArrayList<>();
	public static ArrayList<Menu[]> Menus = new ArrayList<>();
	public static ArrayList<String> MenuNames = new ArrayList<>();
	
	public static ArrayList<String> History = new ArrayList<>();
	
	public Menu(String id){this.id = id;}
	
	public static void init(){
		makeMenu("MainMenu", new Menu[]{
			make("Start"),
			make("Options"),
			make("Exit")
		});
		makeMenu("Pause", new Menu[]{
			make("Continue"),
			make("Quit")
		});
		makeMenu("Quit", new Menu[]{
			make("No"),
			make("Yes")
		});
		makeMenu("Exit", new Menu[]{
			make("No"),
			make("Yes")
		});
		makeMenu("Options", new Menu[]{
			make("Option 1"),
			make("Option 2"),
			make("Option 3")
		});
	}
	
	public static void select(){
		if(currMenu == "MainMenu"){
			switch(Opt){
				case 0:
					Special.ChgLvl(Special.Level);
					//Special.ChgLvl(randInt(lvls));
					Main.GameState = "SWIT"; Shown = false; break;
				case 1: openMenu("Options"); break;
				case 2: openMenu("Exit"); break;
			}
			return;
		}
		if(currMenu == "Pause"){
			switch(Opt){
				case 0: closeMenu(); break;
				case 1: openMenu("Quit"); break;
			}
			return;
		}
		if(currMenu == "Quit"){
			switch(Opt){
				case 0: backMenu(); break;
				case 1: Special.ChgLvl(0); closeMenu(); openMenu("MainMenu"); break;
			}
			return;
		}
		if(currMenu == "Exit"){
			switch(Opt){
				case 0: backMenu(); break;
				case 1: System.exit(0); break;
			}
			return;
		}
		if(currMenu == "Options"){
			switch(Opt){
				case 0: openMenu("Options 1"); break;
				case 1: System.out.println("Option 2"); break;
				case 2: System.out.println("Option 3"); break;
			}
			return;
		}
	}
	
	public static void openMenu(String name){
		Opt = 0;
		Input.focus = "MENU";
		Main.GameState = "MENU";
		Slidey.Shown = false;
		Block.Shown = false;
		Special.Shown = false;
		Shown = true;
		currMenu = name;
		History.add(0, name);
		Master.clear();
		for(Menu m : Menus.get(getMenu(name))){
			Master.add(m);
		}
	}
	
	public static void openMenu(String name, boolean his){
		Opt = 0;
		Input.focus = "MENU";
		Main.GameState = "MENU";
		Slidey.Shown = false;
		Block.Shown = false;
		Special.Shown = false;
		Shown = true;
		currMenu = name;
		if(his) History.add(0, name);
		Master.clear();
		for(Menu m : Menus.get(getMenu(name))){
			Master.add(m);
		}
	}
	
	public static void backMenu(){
		Opt = 0;
		if(currMenu == "Pause"){
			closeMenu();
			return;
		}
		if(History.size() > 1){
			openMenu(History.get(1), false);
			History.remove(0);
		}
	}
	
	public static void closeMenu(){
		Opt = 0;
		Input.focus = "SLIDE";
		Main.GameState = "SWIT";
		
		Slidey.Shown = true;
		Block.Shown = true;
		Special.Shown = true;
		Shown = false;
		History.clear();
	}
	
	public static void drawMenu(Graphics g){
		if(Shown){
			int place = 17;
			g.drawString(currMenu, 0, 17);
			for(Menu m : Master){
				g.drawString(m.id, 17, place + 17);
				place += 17;
			}
			g.drawString("O", 0, Opt*17 + 17*2);
		}
	}
	
	public static void chgMenu(boolean dir){
		//true = down, false = up;
		if(dir) Opt++;
		if(!dir) Opt--;
		
		if(Opt == Master.size()) Opt = 0;
		if(Opt == -1) Opt = Master.size() - 1;
	}
	
	public static Menu make(String name){
		return new Menu(name);
	}
	
	public static void makeMenu(String name, Menu[] list){
		MenuNames.add(name);
		Menus.add(list);
	}
	
	public static Integer getMenu(String name){
		int place = 0;
		for(String s : MenuNames){
			if(s == name) return place;
			place++;
		}
		return -1;
	}
	
	public static String getMenu(Integer place){
		return MenuNames.get(place);
	}
}