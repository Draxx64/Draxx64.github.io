import java.awt.*;
import javax.swing.*;

public class Special extends Main{
	
	public static Integer Level = 0;
	public static boolean ForceFin = false;
	
	public static boolean Shown = false;
	public static int Finx = 0;
	public static int Finy = 0;
	
	public static void Restart(){
		ChgLvl(Level);
	}
	
	public static void Detect(){
		Finished();
	}
	
	public static void makeFin(int x, int y){
		Finx = x*32;
		Finy = y*32;
	}
	
	public static void drawSpecial(Graphics g){
		if(Shown){
			g.drawImage(Sprite.Finish, Finx, Finy, Engine.f);
		}
	}
	
	public static void ChgLvl(int level){
		Level = level - 1;
		ForceFin = true;
		Finished();
		ForceFin = false;
	}
	
	public static void Finished(){
		if((Slidey.x == Finx && Slidey.y == Finy) || ForceFin){
			Level += 1;
			Slidey.dir = 0;
			switch(Level){
				case 0: Levels.Level1(); break;
				case 1: Levels.Level2(); break;
				case 2: Levels.Level3(); break;
				case 3: Levels.Level4(); break;
				case 4: Levels.Level5(); break;
				case 5: Levels.Level6(); break;
				case 6: /*Levels.Level7();*/ break;
				case 7: System.out.println("LEVEL NOT FOUND"); break;
				case 8: System.out.println("LEVEL NOT FOUND"); break;
				case 9: System.out.println("LEVEL NOT FOUND"); break;
				case 10: System.out.println("LEVEL NOT FOUND"); break;
				case 11: System.out.println("LEVEL NOT FOUND"); break;
				case 12: System.out.println("LEVEL NOT FOUND"); break;
				case 13: System.out.println("LEVEL NOT FOUND"); break;
				case 14: System.out.println("LEVEL NOT FOUND"); break;
				case 15: System.out.println("LEVEL NOT FOUND"); break;
			}
		}
	}
}