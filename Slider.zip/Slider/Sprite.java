import java.awt.*;
import javax.swing.*;

public class Sprite extends Main{
	public static Image Slidey = getArt("Slidey");
	public static Image Block = getArt("Block");
	public static Image Finish = getArt("Finish");
	public static Image Key = getArt("Key");
	public static Image Door = getArt("Door");
	public static Image HasKey = getArt("HasKey");
	
	public static Image getArt(String name){
		return new ImageIcon(ClassLoader.getSystemResource("").getPath().split(".bin/")[0] + "Art/" + name + ".png").getImage();
	}
	
}