import java.awt.*;
import javax.swing.*;

public class Sprite extends Main{
	public static Image Slidey = new ImageIcon("Art/Slidey.png").getImage();
	public static Image Block = new ImageIcon("Art/Block.jpg").getImage();
	public static Image Finish = new ImageIcon("Art/Finish.png").getImage();
	public static Image Key = new ImageIcon("Art/Key.png").getImage();
	public static Image Door = new ImageIcon("Art/Door.png").getImage();
	public static Image HasKey = new ImageIcon("Art/HasKey.png").getImage();
}