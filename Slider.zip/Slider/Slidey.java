import java.awt.*;
import javax.swing.*;

public class Slidey extends Main{
	
	public static boolean Shown = false;
	public static boolean HK = false;
	
	public static int x = 0;
	public static int y = 224;
	
	public static int speed = 8;
	
	public static int dir = 0;
	
	public static boolean Detect(){
		int nx = x;
		int ny = y;
		int by = y;
		int bx = x;
		boolean deldoor = false;
		Door deledoor = new Door("", 0, 0);
		boolean Yeas = false;
		switch(dir){
			case 0: nx = x; ny = y; break;
			case 1: ny -= speed; by -= 32; break;
			case 2: nx += speed; bx += 32; break;
			case 3: ny += speed; by += 32; break;
			case 4: nx -= speed; bx -= 32; break;
		}
		for(Block b : Block.BlockList){
			if(nx > Engine.screenWidth-32 || ny > Engine.screenHeight-32 || nx < 0 || ny < 0){
				Yeas = true;
			}	
			if((bx == b.x && by == b.y) || (nx == b.x && ny == b.y)){
				Yeas = true;
			}
		}
		for(Door d : Door.DoorKey){
			if(d.type == "Key" && x == d.x && y == d.y){
				if(Slidey.HK){
					System.out.println("ERROR");
					System.out.println("YOU TOUCHED A KEY WHILE ALREADY HAVING ONE");
					System.out.println("PLEASE WORK AROUND THIS");
					System.exit(0);
				}
				if(!Slidey.HK){
					Slidey.HK = true;
					deledoor = d;
					deldoor = true;
				}
			}
			if(d.type == "Door" && bx == d.x && by == d.y){
				if(!Slidey.HK){
					return true;
				}
				if(Slidey.HK){
					Slidey.HK = false;
					deledoor = d;
					deldoor = true;
				}
			}
		}
		if(deldoor) Door.DoorKey.remove(deledoor);
		if(Yeas) return true;
		if(!Yeas) return false;
		System.out.println("NEVER PRINT THIS EVER");
		return true;
	}
	
	public static void make(int sx, int sy){
		x = sx*32;
		y = sy*32;
	}
	
	public static void Move(){
		if(!Detect()){
			Input.focus = "MOVE";
			switch(dir){
				case 0: x += 0; y += 0; Input.focus = "SLIDE"; break;
				case 1: y -= speed; break;
				case 2: x += speed; break;
				case 3: y += speed; break;
				case 4: x -= speed; break;
			}
		}
		else{
			Input.focus = "SLIDE";
		}
		Special.Detect();
	}
	
	public static void drawSlidey(Graphics g){
		if(Shown){
			if(HK) g.drawImage(Sprite.HasKey, x, y, Engine.f);
			if(!HK) g.drawImage(Sprite.Slidey, x, y, Engine.f);
		}
	}
}