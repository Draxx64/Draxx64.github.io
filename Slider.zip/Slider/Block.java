import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;

public class Block extends Main{
	
	public static boolean Shown = false;
	
	public int x = 0;
	public int y = 0;
	
	public static Character wall = 'H';
	public static Character empty = '-';
	public static Character key = 'K';
	public static Character door = 'D';
	public static Character slide = 'S';
	public static Character finish = 'F';
	
	public static ArrayList<Block> BlockList = new ArrayList<Block>();
	
	public Block(){
	}
	
	public Block(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	public static void make(int x, int y){
		BlockList.add(new Block(x*32, y*32));
	}
	
	public static void mapGen(String[] list){
		int hasFin = 0;
		int hasSli = 0;
		if(list.length != 8){
			System.out.println("ERROR ON LEVEL: " + Special.Level);
			System.out.println("COLUMN ERROR");
			System.out.println("COLUMN LENGTH IS: " + list.length);
			System.exit(0);
		}
		for(String s : list){
			if(s.length() != 8){
				System.out.println("ERROR ON LEVEL: " + Special.Level);
				System.out.println("ROW ERROR");
				System.out.println("ROW LENGTH IS: " + s.length());
				System.out.println("ROW: " + s);
				System.exit(0);
			}
			if(s.contains(slide.toString())) hasSli += 1;
			if(s.contains(finish.toString())) hasFin += 1;
		}
		
		if(hasFin != 1 || hasSli != 1){
			System.out.println("ERROR ON LEVEL: " + Special.Level);
			System.out.println("SLIDER OR FINISH ERROR");
			System.out.println("SLIDERS: " + hasSli);
			System.out.println("FINISHES: " + hasFin);
			System.exit(0);
		}
		
		int y = 0;
		int x = 0;
		
		for(String s : list){
			char[] blocks = s.toCharArray();
			for(Character c : blocks){
				if(c == wall){
					make(x, y);
				}
				if(c == key){
					Door.make("Key", x, y);
				}
				if(c == door){
					Door.make("Door", x, y);
				}
				if(c == slide){
					Slidey.make(x, y);
				}
				if(c == finish){
					Special.makeFin(x, y);
				}
				x++;
			}
			x = 0;
			y++;
		}
	}
	
	public static void drawBlock(Graphics g){
		if(Shown){
			for(Block b : BlockList){
				g.drawImage(Sprite.Block, b.x, b.y, Engine.f);
			}
		}
	}
}