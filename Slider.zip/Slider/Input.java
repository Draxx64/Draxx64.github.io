import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Input extends Main{
	
	public static String focus = "NONE";
	
	public static void init(){
		Engine.f.addKeyListener(new KeyListener(){
			@Override
			public void keyPressed(KeyEvent e){
				int key = e.getKeyCode();
				if(key == KeyEvent.VK_P){
					System.exit(0);
				}
				if(focus == "MENU"){
					if(key == KeyEvent.VK_UP || key == KeyEvent.VK_W){
						Menu.chgMenu(false);
					}
					if(key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S){
						Menu.chgMenu(true);
					}
					if(key == KeyEvent.VK_SPACE){
						Menu.select();
					}
					if(key == KeyEvent.VK_ESCAPE){
						Menu.backMenu();
						return;
					}
				}
				if(focus == "SLIDE"){
					if(key == KeyEvent.VK_R){
						Special.Restart();
					}
					if(key == KeyEvent.VK_O){
						Special.ChgLvl(++Special.Level);
					}
					if(key == KeyEvent.VK_I){
						Special.ChgLvl(--Special.Level);
					}
					if(key == KeyEvent.VK_ESCAPE){
						Menu.openMenu("Pause");
						GameState = "MENU";
						return;
					}
					if(key == KeyEvent.VK_UP || key == KeyEvent.VK_W){
						Slidey.dir = 1;
					}
					if(key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D){
						Slidey.dir = 2;
					}
					if(key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S){
						Slidey.dir = 3;
					}
					if(key == KeyEvent.VK_LEFT || key == KeyEvent.VK_A){
						Slidey.dir = 4;
					}
				}
				if(focus == "MOVE"){
					if(key == KeyEvent.VK_R){
						Special.Restart();
					}
					if(key == KeyEvent.VK_ESCAPE){
						Menu.openMenu("Pause");
						GameState = "MENU";
					}
				}
			}
			@Override
			public void keyReleased(KeyEvent e){
				int key = e.getKeyCode();
				if(focus == "SLIDE"){
				}
			}
			@Override
			public void keyTyped(KeyEvent e){
				int key = e.getKeyCode();
				
			}
		});
	}
}