public class Init extends Main{
	
	public static void INIT(){
		System.out.println("ENGINE");
		Engine.init();
		System.out.println("INPUT");
		Input.init();
		System.out.println("MENU");
		Menu.init();
		
		System.out.println("DONE\n|");
	}
}