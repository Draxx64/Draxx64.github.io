import java.awt.*;
import javax.swing.*;

public class Engine extends Main{
	public static Integer screenWidth = 256; //32*32 squares, 8*8
	public static Integer screenHeight = 256;
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		Block.drawBlock(g);
		Special.drawSpecial(g);
		Door.drawDoor(g);
		
		Slidey.drawSlidey(g);
		
		Menu.drawMenu(g);
		
		/*
		g.drawString(((Integer) Special.Level).toString(), 244, 250);
		g.drawString(((Integer) Slidey.speed).toString(), 225, 200);
		g.drawString(Input.focus, 200, 250);
		
		g.drawString(((Integer) Main.frames).toString(), 200, 236);
		*/
	}
	
	static JFrame f = new JFrame("Swit");
	static JPanel p = new JPanel();
	
	static Engine ex = new Engine();
	
	public static void init(){
		f.dispose();
		f.add(ex);
		
		p.setFocusable(true);
		p.requestFocusInWindow();
		f.setSize(new Dimension(screenWidth, screenHeight + 25));
		f.setVisible(true);
	}
}