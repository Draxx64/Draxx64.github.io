public class Levels extends Block{
	
	public static void Reset(){
		Block.Shown = false;
		Door.Shown = false;
		Block.BlockList.clear();
		Door.DoorKey.clear();
		Slidey.HK = false;
		Slidey.Shown = true;
		Block.Shown = true;
		Special.Shown = true;
		Door.Shown = true;
	}
	
	public static void Level1(){
		Reset();
		Block.mapGen(new String[]{
			"FHHHHHHH",
			"--------",
			"HHHHHHH-",
			"--------",
			"-HHHHHHH",
			"--------",
			"HHHHHHH-",
			"S-------"
		});
	}
	
	public static void Level2(){
		Reset();
		Block.mapGen(new String[]{
			"FH--H---",
			"----H-H-",
			"----H-H-",
			"H---H-H-",
			"----H-H-",
			"--H---H-",
			"HHHHHHH-",
			"S-------"
		});
	}
	
	public static void Level3(){
		Reset();
		Block.mapGen(new String[]{
			"--------",
			"-----H--",
			"-H------",
			"---FH---",
			"--H-----",
			"------H-",
			"H-------",
			"S-------"
		});
	}
	
	public static void Level4(){
		Reset();
		Block.mapGen(new String[]{
			"HHHHHHHH",
			"H------H",
			"H------H",
			"H------H",
			"F----HDH",
			"HH---H-H",
			"---K---H",
			"SHHHHHHH"
		});
	}
	
	public static void Level5(){
		Reset();
		Block.mapGen(new String[]{
			"HHHHHHHH",
			"H------H",
			"H------H",
			"H------H",
			"HF-----H",
			"HHHHHH-H",
			"H-K-HH-H",
			"S--D---H"
		});
	}
	
	public static void Level6(){
		Reset();
		Block.mapGen(new String[]{
			"K----H-H",
			"---H---H",
			"-HHS---H",
			"D--H---H",
			"-------F",
			"H----H-H",
			"--HH-H-H",
			"-------H"
		});
	}
	
	public static void Level7(){
		Reset();
		Block.mapGen(new String[]{
			"-------F",
			"--------",
			"-KHK----",
			"-HSH----",
			"-KHK----",
			"-----D--",
			"-----H--",
			"----H-H-"
		});
	}
}

/*
KEY:

//H = BLOCK
//- = EMPTY
//K = KEY
//D = DOOR
//S = SLIDEY
//F = FINISH


TEMPLATE:

Block.mapGen(new String[]{
			"--------",
			"--------",
			"--------",
			"--------",
			"--------",
			"--------",
			"--------",
			"--------"
		});

*/