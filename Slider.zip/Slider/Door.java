import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;

public class Door extends Main{
	
	public static boolean Shown = false;
	
	public String type = "TYPE";
	public int x = 0;
	public int y = 0;
	
	public static ArrayList<Door> DoorKey = new ArrayList<>();
	
	public Door(){}
	
	public Door(String name, int dx, int dy){
		this.type = name;
		this.x = dx;
		this.y = dy;
	}
	
	public static void make(String name, int x, int y){
		DoorKey.add(new Door(name, x*32, y*32));
	}
	
	public static void drawDoor(Graphics g){
		if(Shown){
			for(Door d : DoorKey){
				if(d.type == "Door"){
					g.drawImage(Sprite.Door, d.x, d.y, Engine.f);
				}
				if(d.type == "Key"){
					g.drawImage(Sprite.Key, d.x, d.y, Engine.f);
				}
			}
		}
	}
}