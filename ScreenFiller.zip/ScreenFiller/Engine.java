import java.util.ArrayList;
import java.util.Random;

import java.awt.*;
import javax.swing.*;

public class Engine extends Main{
	
	public static Integer screenWidth = 500;
	public static Integer screenHeight = 500;
	
	public static Image Background;
	
	@Override
	public void paintComponent(Graphics ge){
		super.paintComponent(ge);
		Graphics2D g = (Graphics2D) ge;
		g.drawImage(Engine.Background, 0, 0, 1920, 1080, Engine.f);
	}
	
	static JFrame f = new JFrame("ScreenFiller");
	static JPanel p = new JPanel();
	
	static Engine ex = new Engine();
	static Engine console = new Engine();
	
	public static void init(){
		
		f.dispose();
		f.add(ex);
		
		p.setFocusable(true);
		p.requestFocusInWindow();
		f.setSize(new Dimension(screenWidth, screenHeight + 34));
		f.setResizable(true);
		f.setVisible(true);
		f.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		
	}
}