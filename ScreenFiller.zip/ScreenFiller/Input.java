import java.util.ArrayList;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.net.*;
import java.io.*;

import javax.sound.sampled.*;

public class Input extends Main{
	
	public static Boolean MouseDown = false;
	
	public static void init(){
		Engine.f.addKeyListener(new KeyListener(){
			@Override
			public void keyPressed(KeyEvent e){
				int key = e.getKeyCode();
				
				if(key == KeyEvent.VK_ESCAPE){
					System.exit(0);
				}
				
				if(key == KeyEvent.VK_SPACE){
					full = !full;
					if(full){
						Engine.f.dispose();
						Engine.f.setUndecorated(true);
						Engine.f.setAlwaysOnTop(true);
						Engine.f.setExtendedState(JFrame.MAXIMIZED_BOTH);
						GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().setFullScreenWindow(Engine.f);
						Engine.init();
					}
					if(!full){
						Engine.f.dispose();
						Engine.f.setUndecorated(false);
						Engine.f.setExtendedState(JFrame.NORMAL);
						Engine.f.setAlwaysOnTop(false);
						Engine.init();
					}
				}
				
			}
			@Override
			public void keyReleased(KeyEvent e){
				int key = e.getKeyCode();
				
			}
			
			@Override public void keyTyped(KeyEvent e){int key = e.getKeyCode();}
			
		});
		
	}
}