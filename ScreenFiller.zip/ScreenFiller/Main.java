import java.awt.*;
import javax.swing.*;

import java.net.*;
import java.io.*;

public class Main extends JPanel{
	
	public static Integer framerate = 60;
	
	public static Integer frame = 0;
	
	public static Boolean full = false;
	
	public static String getFilePath(String str){
		return ClassLoader.getSystemResource("").getPath().split(".bin/")[0] + str;
	}
	
	public static Image getImage(String path){
		return new ImageIcon(getFilePath(path)).getImage();
	}
	
	public static void main(String[] args){
		
		System.out.println("im starting for you...");
		
		Engine.init();
		
		Input.init();
		
		if(args.length > 0 && new File(args[0]).exists()){
			System.out.println("using: " + args[0]);
			Engine.Background = new ImageIcon(args[0]).getImage();
		}
		else{
			System.out.println("using: input.png");
			Engine.Background = getImage("input.png");
		}
		
		System.out.println("im done...\n|");
		
		while(true){
			try{Thread.sleep(1000/framerate);} catch(InterruptedException e){}
			
			try{
				Engine.ex.repaint();
			}
			catch(java.util.ConcurrentModificationException e){
				System.out.println("Modification");
			}
			
			frame++;
			
		}
	}
}