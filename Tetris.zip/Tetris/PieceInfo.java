import java.awt.*;
import javax.swing.*;

import java.util.ArrayList;

public class PieceInfo extends Main{
	
	public static Integer screenWidth = 16*10;
	public static Integer screenHeight = 20*16 + 32 + 2;
	
	public static ArrayList<Piece> nextPieces = new ArrayList<>();
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setFont(new Font("MONOSPACED", Font.BOLD, 14));
		
		g.setColor(new Color(0, 0, 0));
		g.fillRect(0, 0, screenWidth, screenHeight);
		
		g.setColor(new Color(0, 0, 255));
		for(int i = 1; i < nextPieces.size(); i++){
			g.fillRect(
				(2 + nextPieces.get(i).p1.x)*16,
				(4*(i - 1) + 3 + nextPieces.get(i).p1.y)*16, 
				16, 
				16
			);
			g.fillRect(
				(2 + nextPieces.get(i).p2.x)*16,
				(4*(i - 1) + 3 + nextPieces.get(i).p2.y)*16, 
				16, 
				16
			);
			g.fillRect(
				(2 + nextPieces.get(i).p3.x)*16,
				(4*(i - 1) + 3 + nextPieces.get(i).p3.y)*16, 
				16, 
				16
			);
			g.fillRect(
				(2 + nextPieces.get(i).p4.x)*16,
				(4*(i - 1) + 3 + nextPieces.get(i).p4.y)*16, 
				16, 
				16
			);
		}
		
	}
	
	static JFrame f = new JFrame("Piece Info");
	static JPanel p = new JPanel();
	
	static PieceInfo ex = new PieceInfo();
	
	public static void init(){
		
		f.dispose();
		f.add(ex);
		
		p.setFocusable(true);
		p.requestFocusInWindow();
		f.setSize(new Dimension(screenWidth, screenHeight));
		f.setResizable(true);
		f.setVisible(true);
		f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		f.setLocation(Engine.screenWidth + 4, 0);
	}
}
