import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Input extends Main{
	
	public static Boolean pRight = false;
	public static Boolean pLeft = false;
	public static Boolean pDown = false;
	
	public static void init(){
		Engine.f.addKeyListener(new KeyListener(){
			@Override
			public void keyPressed(KeyEvent e){
				int key = e.getKeyCode();
				
				if(key == KeyEvent.VK_ESCAPE){
					System.exit(9);
				}
				
				if(!Board.pause){
					
					// A and D are for moving
					// left and right are for rotating
					// s and down are for moving faster
					// space is to set piece in place at bottom
					
					// move left
					if(key == KeyEvent.VK_A){
						pLeft = true;
						pRight = false;
						timeFrame = frame;
					}
					
					// move right
					if(key == KeyEvent.VK_D){
						pRight = true;
						pLeft = false;
						timeFrame = frame;
					}
					
					// rotate left
					if(key == KeyEvent.VK_LEFT){
						Piece.rotate(false);
					}
					
					// rotate right
					if(key == KeyEvent.VK_RIGHT){
						Piece.rotate(true);
					}
					
					// move down faster
					if(key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S){
						pDown = true;
					}
					
					// set at bottom
					if(key == KeyEvent.VK_SPACE){
						int y = Piece.currPiece.yPos;
						while(!(
							y + Piece.currPiece.p1.y > 19
							||
							y + Piece.currPiece.p2.y > 19
							||
							y + Piece.currPiece.p3.y > 19
							||
							y + Piece.currPiece.p4.y > 19
							
							||
							
							Board.board[Piece.currPiece.xPos + Piece.currPiece.p1.x][y + Piece.currPiece.p1.y]
							||
							Board.board[Piece.currPiece.xPos + Piece.currPiece.p2.x][y + Piece.currPiece.p2.y]
							||
							Board.board[Piece.currPiece.xPos + Piece.currPiece.p3.x][y + Piece.currPiece.p3.y]
							||
							Board.board[Piece.currPiece.xPos + Piece.currPiece.p4.x][y + Piece.currPiece.p4.y]
						)){
							y++;
						}
						Piece.currPiece.yPos = y;
						Board.scoreTempAdd += 3;
						Board.update(-1);
					}
					
					if(key == KeyEvent.VK_SHIFT){
						Board.hold();
					}
					
				}
				
				if(key == KeyEvent.VK_ENTER){
					if(lose.equals("You Lost!")){
						Board.init();
						Board.pause = false;
					}
				}
				
			}
			@Override
			public void keyReleased(KeyEvent e){
				int key = e.getKeyCode();
				
				if(key == KeyEvent.VK_A){
					pLeft = false;
				}
				if(key == KeyEvent.VK_D){
					pRight = false;
				}
				if(key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S){
					pDown = false;
				}
				
			}
			@Override
			public void keyTyped(KeyEvent e){
				int key = e.getKeyCode();
				
			}
		});
		
	}
}