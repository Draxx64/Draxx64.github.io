import java.awt.*;
import javax.swing.*;

public class Main extends JPanel{
	
	public static Integer framerate = 30;
	
	public static Integer frame = 0;
	
	public static Integer timeFrame = 0;
	
	public static Long score = 0L;
	public static String lose = "";
	public static String message = "";
	
	public static void main(String[] args){
		
		System.out.println("STARTING...");
		
		PieceInfo.init();
		
		Console.init();
		
		Input.init();
		
		Board.init();
		
		Engine.init();
		
		System.out.println("STARTED\n|");
		
		while(true){
			try{Thread.sleep(1000/framerate);} catch(InterruptedException e){}
			
			Board.update(frame);
			
			if(Input.pLeft && Board.canMoveLeft && (frame - timeFrame) % 6 == 0){
				if(Piece.currPiece.xPos + Piece.currPiece.p1.x != 0){
					Piece.currPiece.xPos--;
				}
			}
			if(Input.pRight && Board.canMoveRight && (frame - timeFrame) % 6 == 0){
				if(Piece.currPiece.xPos + Piece.currPiece.p4.x != 9){
					Piece.currPiece.xPos++;
				}
			}
			
			try{
				Engine.ex.repaint();
				PieceInfo.ex.repaint();
				Console.ex.repaint();
			}
			catch(java.util.ConcurrentModificationException e){
				System.out.println("Modification");
			}
			
			frame++;
			
		}
	}
}