import java.awt.*;
import javax.swing.*;

public class Console extends Main{
	
	public static Integer screenWidth = 255;
	public static Integer screenHeight = 255 + 32 + 2;
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setFont(new Font("MONOSPACED", Font.BOLD, 14));
		
		g.drawString("rotation: " + Piece.currPiece.rot, 0, 14*1);
		g.drawString("lines: " + Board.lines, 0, 14*2);
		if(Board.scoreTempAdd > 0){
			g.drawString("score: " + score + " + " + Board.scoreTempAdd, 0, 14*3);
		}
		if(Board.scoreTempAdd == 0){
			g.drawString("score: " + score, 0, 14*3);
		}
		if(Board.scoreAdd < frame && Board.canAdd){
			score += Board.scoreTempAdd;
			Board.scoreTempAdd = 0;
			Board.canAdd = false;
		}
		
		g.drawString(lose, 0, 14*5);
		g.drawString(message, 0, 14*6);
	}
	
	static JFrame f = new JFrame("CONSOLE");
	static JPanel p = new JPanel();
	
	static Console ex = new Console();
	
	public static void init(){
		
		f.dispose();
		f.add(ex);
		
		p.setFocusable(true);
		p.requestFocusInWindow();
		f.setSize(new Dimension(screenWidth, screenHeight));
		f.setResizable(true);
		f.setVisible(true);
		f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		f.setLocation(0, Engine.screenHeight + 34);
	}
}
