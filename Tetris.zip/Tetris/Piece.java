import java.awt.*;
import javax.swing.*;

import java.util.Random;

public class Piece extends Main{
	
	public String type = "T";
	public Integer rot = 0;
	public Integer xPos = 0;
	public Integer yPos = 0;
	public Point p1 = new Point(0, 0);
	public Point p2 = new Point(1, 0);
	public Point p3 = new Point(2, 0);
	public Point p4 = new Point(3, 0);
	
	public static Piece currPiece;
	
	public static Random rand = new Random();
	public static String randPiece(){
		int x = rand.nextInt(7);
		if(x == 0) return "T";
		if(x == 1) return "I";
		if(x == 2) return "O";
		if(x == 3) return "L";
		if(x == 4) return "J";
		if(x == 5) return "Z";
		if(x == 6) return "S";
		return "FUCK";
	}
	
	public static void rotate(Boolean dir){
		if(dir) currPiece.rot++;
		if(!dir) currPiece.rot--;
		if(currPiece.rot == 4) currPiece.rot = 0;
		if(currPiece.rot == -1) currPiece.rot = 3;
		switch(currPiece.type){
			case("T"):
				switch(currPiece.rot){
					case(0):
						currPiece.p1 = new Point(0, 1);
						currPiece.p2 = new Point(1, 0);
						currPiece.p3 = new Point(1, 1);
						currPiece.p4 = new Point(2, 1);
						break;
					case(1):
						currPiece.p1 = new Point(1, 0);
						currPiece.p2 = new Point(1, 1);
						currPiece.p3 = new Point(1, 2);
						currPiece.p4 = new Point(2, 1);
						break;
					case(2):
						currPiece.p1 = new Point(0, 1);
						currPiece.p2 = new Point(1, 1);
						currPiece.p3 = new Point(1, 2);
						currPiece.p4 = new Point(2, 1);
						break;
					case(3):
						currPiece.p1 = new Point(0, 1);
						currPiece.p2 = new Point(1, 0);
						currPiece.p3 = new Point(1, 1);
						currPiece.p4 = new Point(1, 2);
						break;
				}
				break;
			case("I"):
				switch(currPiece.rot){
					case(0):
						currPiece.p1 = new Point(0, 1);
						currPiece.p2 = new Point(1, 1);
						currPiece.p3 = new Point(2, 1);
						currPiece.p4 = new Point(3, 1);
						break;
					case(1):
						currPiece.p1 = new Point(2, 0);
						currPiece.p2 = new Point(2, 1);
						currPiece.p3 = new Point(2, 2);
						currPiece.p4 = new Point(2, 3);
						break;
					case(2):
						currPiece.p1 = new Point(0, 2);
						currPiece.p2 = new Point(1, 2);
						currPiece.p3 = new Point(2, 2);
						currPiece.p4 = new Point(3, 2);
						break;
					case(3):
						currPiece.p1 = new Point(1, 0);
						currPiece.p2 = new Point(1, 1);
						currPiece.p3 = new Point(1, 2);
						currPiece.p4 = new Point(1, 3);
						break;
				}
				break;
			case("L"):
				switch(currPiece.rot){
					case(0):
						currPiece.p1 = new Point(1, 1);
						currPiece.p2 = new Point(1, 2);
						currPiece.p3 = new Point(2, 1);
						currPiece.p4 = new Point(3, 1);
						break;
					case(1):
						currPiece.p1 = new Point(1, 1);
						currPiece.p2 = new Point(2, 1);
						currPiece.p3 = new Point(2, 2);
						currPiece.p4 = new Point(2, 3);
						break;
					case(2):
						currPiece.p1 = new Point(0, 2);
						currPiece.p2 = new Point(1, 2);
						currPiece.p3 = new Point(2, 2);
						currPiece.p4 = new Point(2, 1);
						break;
					case(3):
						currPiece.p1 = new Point(1, 0);
						currPiece.p2 = new Point(1, 1);
						currPiece.p3 = new Point(1, 2);
						currPiece.p4 = new Point(2, 2);
						break;
				}
				break;
			case("J"):
				switch(currPiece.rot){
					case(0):
						currPiece.p1 = new Point(0, 1);
						currPiece.p2 = new Point(1, 1);
						currPiece.p3 = new Point(2, 1);
						currPiece.p4 = new Point(2, 2);
						break;
					case(1):
						currPiece.p1 = new Point(1, 2);
						currPiece.p2 = new Point(2, 0);
						currPiece.p3 = new Point(2, 1);
						currPiece.p4 = new Point(2, 2);
						break;
					case(2):
						currPiece.p1 = new Point(1, 1);
						currPiece.p2 = new Point(1, 2);
						currPiece.p3 = new Point(2, 2);
						currPiece.p4 = new Point(3, 2);
						break;
					case(3):
						currPiece.p1 = new Point(1, 1);
						currPiece.p2 = new Point(1, 2);
						currPiece.p3 = new Point(1, 3);
						currPiece.p4 = new Point(2, 1);
						break;
				}
				break;
			case("Z"):
				switch(currPiece.rot){
					case(0):
						currPiece.p1 = new Point(0, 0);
						currPiece.p2 = new Point(1, 0);
						currPiece.p3 = new Point(1, 1);
						currPiece.p4 = new Point(2, 1);
						break;
					case(1):
						currPiece.p1 = new Point(1, 0);
						currPiece.p2 = new Point(1, 1);
						currPiece.p3 = new Point(0, 1);
						currPiece.p4 = new Point(0, 2);
						break;
					case(2):
						currPiece.p1 = new Point(0, 0);
						currPiece.p2 = new Point(1, 0);
						currPiece.p3 = new Point(1, 1);
						currPiece.p4 = new Point(2, 1);
						break;
					case(3):
						currPiece.p1 = new Point(1, 0);
						currPiece.p2 = new Point(1, 1);
						currPiece.p3 = new Point(0, 1);
						currPiece.p4 = new Point(0, 2);
						break;
				}
				break;
			case("S"):
				switch(currPiece.rot){
					case(0):
						currPiece.p1 = new Point(0, 1);
						currPiece.p2 = new Point(1, 1);
						currPiece.p3 = new Point(1, 0);
						currPiece.p4 = new Point(2, 0);
						break;
					case(1):
						currPiece.p1 = new Point(0, 0);
						currPiece.p2 = new Point(0, 1);
						currPiece.p3 = new Point(1, 1);
						currPiece.p4 = new Point(1, 2);
						break;
					case(2):
						currPiece.p1 = new Point(0, 1);
						currPiece.p2 = new Point(1, 1);
						currPiece.p3 = new Point(1, 0);
						currPiece.p4 = new Point(2, 0);
						break;
					case(3):
						currPiece.p1 = new Point(0, 0);
						currPiece.p2 = new Point(0, 1);
						currPiece.p3 = new Point(1, 1);
						currPiece.p4 = new Point(1, 2);
						break;
				}
				break;
		}
		
		while(
			currPiece.xPos + currPiece.p4.x > 9
			||
			Board.board[currPiece.xPos + currPiece.p4.x][currPiece.yPos + currPiece.p4.y]
		){
			Piece.currPiece.xPos--;
		}
		while(
			Piece.currPiece.xPos + Piece.currPiece.p1.x < 0
			||
			Board.board[currPiece.xPos + currPiece.p1.x][currPiece.yPos + currPiece.p1.y]
		){
			Piece.currPiece.xPos++;
		}
	}
	
	public Piece(String t){
		// P1 HAS TO BE THE LEFTMOST P#
		// P4 HAS TO BE THE RIGHTMOST P#
		//[0][1][0][0]
		//[1][1][1][0]
		//[0][0][0][0]
		//t piece
		type = t;
		rot = 0;
		switch(type){
			case("T"):
				xPos = rand.nextInt(2) + 3;
				yPos = 0;
				p1 = new Point(0, 1);
				p2 = new Point(1, 0);
				p3 = new Point(1, 1);
				p4 = new Point(2, 1);
				break;
			case("I"):
				xPos = 3;
				yPos = 0;
				p1 = new Point(0, 1);
				p2 = new Point(1, 1);
				p3 = new Point(2, 1);
				p4 = new Point(3, 1);
				break;
			case("O"):
				xPos = 4;
				yPos = 0;
				p1 = new Point(0, 0);
				p2 = new Point(1, 0);
				p3 = new Point(0, 1);
				p4 = new Point(1, 1);
				break;
			//more left
			case("L"):
				xPos = rand.nextInt(2) + 3;
				yPos = 0;
				p1 = new Point(1, 1);
				p2 = new Point(1, 2);
				p3 = new Point(2, 1);
				p4 = new Point(3, 1);
				break;
			//more right
			case("J"):
				xPos = rand.nextInt(2) + 3;
				yPos = 0;
				p1 = new Point(0, 0);
				p2 = new Point(1, 0);
				p3 = new Point(2, 0);
				p4 = new Point(2, 1);
				break;
			//more left
			case("Z"):
				xPos = rand.nextInt(2) + 3;
				yPos = 0;
				p1 = new Point(0, 0);
				p2 = new Point(1, 0);
				p3 = new Point(1, 1);
				p4 = new Point(2, 1);
				break;
			//more right
			case("S"):
				xPos = rand.nextInt(2) + 3;
				yPos = 0;
				p1 = new Point(0, 1);
				p2 = new Point(1, 1);
				p3 = new Point(1, 0);
				p4 = new Point(2, 0);
				break;
		}
	}
	
	public Piece(){}
}