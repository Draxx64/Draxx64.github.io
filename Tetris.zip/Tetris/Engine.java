import java.awt.*;
import javax.swing.*;

public class Engine extends Main{
	
	//10 x 20, 16x16
	public static Integer sW = 10 * 16 + 2;
	public static Integer sH = 20 * 16 + 2;
	public static Integer screenWidth = sW;
	public static Integer screenHeight = sH;
	
	public static String out = "BLANK";
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setFont(new Font("MONOSPACED", Font.BOLD, 14));
		
		//draw back
		g.setColor(new Color(0, 0, 0));
		g.fillRect(0, 0, sW, sH);
		
		for(int x = 0 ; x < 10 ; x++){
			for(int y = 0 ; y < 20 ; y++){
				//draw board
				if(Board.board[x][y]){
					g.setColor(new Color(255, 0, 0));
				}
				if(!Board.board[x][y]){
					g.setColor(new Color(0, 0, 255));
				}
				g.fillRect(x*16, y*16, 16, 16);
				
				//draw grid
				g.setColor(new Color(255, 255, 255));
				g.drawRect(x*16, y*16, 16, 16);
			}
		}
		//draw piece
		g.setColor(new Color(0, 255, 0));
		g.fillRect(
			(Piece.currPiece.xPos + Piece.currPiece.p1.x)*16,
			(Piece.currPiece.yPos + Piece.currPiece.p1.y)*16, 
			16, 
			16
		);
		g.fillRect(
			(Piece.currPiece.xPos + Piece.currPiece.p2.x)*16,
			(Piece.currPiece.yPos + Piece.currPiece.p2.y)*16, 
			16, 
			16
		);
		g.fillRect(
			(Piece.currPiece.xPos + Piece.currPiece.p3.x)*16,
			(Piece.currPiece.yPos + Piece.currPiece.p3.y)*16, 
			16, 
			16
		);
		g.fillRect(
			(Piece.currPiece.xPos + Piece.currPiece.p4.x)*16,
			(Piece.currPiece.yPos + Piece.currPiece.p4.y)*16, 
			16, 
			16
		);
		
		//draw piece outline square
		g.setColor(new Color(255, 0, 255));
		g.drawRect(Piece.currPiece.xPos*16, Piece.currPiece.yPos*16, 16*3, 16*3);
		
		//draw snapped piece
		int y = Piece.currPiece.yPos;
		while(!(
			y + Piece.currPiece.p1.y > 19
			||
			y + Piece.currPiece.p2.y > 19
			||
			y + Piece.currPiece.p3.y > 19
			||
			y + Piece.currPiece.p4.y > 19
			
			||
			
			Board.board[Piece.currPiece.xPos + Piece.currPiece.p1.x][y + Piece.currPiece.p1.y]
			||
			Board.board[Piece.currPiece.xPos + Piece.currPiece.p2.x][y + Piece.currPiece.p2.y]
			||
			Board.board[Piece.currPiece.xPos + Piece.currPiece.p3.x][y + Piece.currPiece.p3.y]
			||
			Board.board[Piece.currPiece.xPos + Piece.currPiece.p4.x][y + Piece.currPiece.p4.y]
		)){
			y++;
		}
		y--;
		g.setColor(new Color(0, 255, 255));
		g.fillRect(
			(Piece.currPiece.xPos + Piece.currPiece.p1.x)*16,
			(y + Piece.currPiece.p1.y)*16, 
			16, 
			16
		);
		g.fillRect(
			(Piece.currPiece.xPos + Piece.currPiece.p2.x)*16,
			(y + Piece.currPiece.p2.y)*16, 
			16, 
			16
		);
		g.fillRect(
			(Piece.currPiece.xPos + Piece.currPiece.p3.x)*16,
			(y + Piece.currPiece.p3.y)*16, 
			16, 
			16
		);
		g.fillRect(
			(Piece.currPiece.xPos + Piece.currPiece.p4.x)*16,
			(y + Piece.currPiece.p4.y)*16, 
			16, 
			16
		);
	}
	
	static JFrame f = new JFrame("Tetris");
	static JPanel p = new JPanel();
	
	static Engine ex = new Engine();
	static Engine console = new Engine();
	
	public static void init(){
		
		f.dispose();
		f.add(ex);
		
		p.setFocusable(true);
		p.requestFocusInWindow();
		f.setSize(new Dimension(screenWidth, screenHeight + 34));
		f.setResizable(true);
		f.setVisible(true);
		f.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	}
}