import java.awt.*;
import javax.swing.*;

public class Board extends Main{
	
	public static Boolean[][] board = new Boolean[10][20];
	public static Integer gameDifficulty = 30;
	
	public static Boolean canMoveLeft = true;
	public static Boolean canMoveRight = true;
	
	public static Integer lines = 0;
	
	public static Boolean pause = false;
	
	public static Integer scoreTemp = 0;
	public static Integer scoreAdd = 0;
	public static Integer scoreTempAdd = 0;
	public static Boolean canAdd = false;
	
	public static void init(){
		for(int x = 0; x < board.length; x++){
			for(int y = 0; y < board[0].length; y++){
				board[x][y] = false;
			}
		}
		for(int i = 0; i < 6; i++){
			PieceInfo.nextPieces.add(new Piece(Piece.randPiece()));
		}
		Piece.currPiece = PieceInfo.nextPieces.get(0);
	}
	
	public static void hold(){
		
	}
	
	public static void update(int inFrame){
		if(pause) return;
		if(inFrame != -1){
			if(frame % gameDifficulty == 0 || (Input.pDown && frame % 3 == 0)){
				Piece.currPiece.yPos++;
				if(Input.pDown){
					scoreTempAdd++;
				}
			}
		}
		
		
		
		//detect stop down
		if(
			Piece.currPiece.yPos + Piece.currPiece.p1.y > 19
			||
			Piece.currPiece.yPos + Piece.currPiece.p2.y > 19
			||
			Piece.currPiece.yPos + Piece.currPiece.p3.y > 19
			||
			Piece.currPiece.yPos + Piece.currPiece.p4.y > 19
			
			||
			
			board[Piece.currPiece.xPos + Piece.currPiece.p1.x][Piece.currPiece.yPos + Piece.currPiece.p1.y]
			||
			board[Piece.currPiece.xPos + Piece.currPiece.p2.x][Piece.currPiece.yPos + Piece.currPiece.p2.y]
			||
			board[Piece.currPiece.xPos + Piece.currPiece.p3.x][Piece.currPiece.yPos + Piece.currPiece.p3.y]
			||
			board[Piece.currPiece.xPos + Piece.currPiece.p4.x][Piece.currPiece.yPos + Piece.currPiece.p4.y]
		){
			Piece.currPiece.yPos--;
			try{
				board[Piece.currPiece.xPos + Piece.currPiece.p1.x][Piece.currPiece.yPos + Piece.currPiece.p1.y] = true;
				board[Piece.currPiece.xPos + Piece.currPiece.p2.x][Piece.currPiece.yPos + Piece.currPiece.p2.y] = true;
				board[Piece.currPiece.xPos + Piece.currPiece.p3.x][Piece.currPiece.yPos + Piece.currPiece.p3.y] = true;
				board[Piece.currPiece.xPos + Piece.currPiece.p4.x][Piece.currPiece.yPos + Piece.currPiece.p4.y] = true;
			}
			catch(ArrayIndexOutOfBoundsException AIOOBEX){
				lose = "You Lost!";
				message = "Press Enter to play again";
				pause = true;
			}
			Integer LC = 0;
			Integer line = -1;
			out: for(int y = 0; y < board[0].length; y++){
				for(int x = 0; x < board.length; x++){
					if(!board[x][y]) continue out;
				}
				lines++;
				LC++;
				scoreTemp += 10;
				for(int x = 0; x < board.length; x++){
					board[x][y] = false;
				}
				line = y;
				for(int y2 = line; y2 > 0; y2--){
					for(int x2 = 0; x2 < board.length; x2++){
						if(board[x2][y2]){
							board[x2][y2] = false;
							board[x2][y2 + 1] = true;
						}
					}
				}
			}
			scoreTempAdd += scoreTemp*(30 - gameDifficulty) + ((Double) Math.pow(scoreTemp, LC)).intValue();
			scoreAdd = frame + framerate*3;
			canAdd = true;
			scoreTemp = 0;
			PieceInfo.nextPieces.remove(0);
			PieceInfo.nextPieces.add(new Piece(Piece.randPiece()));
			Piece.currPiece = PieceInfo.nextPieces.get(0);
		}
		
		//detect can move left
		if(
			Piece.currPiece.xPos + Piece.currPiece.p1.x < 1
			||
			Piece.currPiece.xPos + Piece.currPiece.p2.x < 1
			||
			Piece.currPiece.xPos + Piece.currPiece.p3.x < 1
			||
			Piece.currPiece.xPos + Piece.currPiece.p4.x < 1
			
			||
			
			board[Piece.currPiece.xPos + Piece.currPiece.p1.x - 1][Piece.currPiece.yPos + Piece.currPiece.p1.y]
			||
			board[Piece.currPiece.xPos + Piece.currPiece.p2.x - 1][Piece.currPiece.yPos + Piece.currPiece.p2.y]
			||
			board[Piece.currPiece.xPos + Piece.currPiece.p3.x - 1][Piece.currPiece.yPos + Piece.currPiece.p3.y]
			||
			board[Piece.currPiece.xPos + Piece.currPiece.p4.x - 1][Piece.currPiece.yPos + Piece.currPiece.p4.y]
		){
			canMoveLeft = false;
		}
		else canMoveLeft = true;
		
		//detect can move right
		if(
			Piece.currPiece.xPos + Piece.currPiece.p4.x > 8
			||
			board[Piece.currPiece.xPos + Piece.currPiece.p4.x + 1][Piece.currPiece.yPos + Piece.currPiece.p4.y]
		){
			canMoveRight = false;
		}
		else canMoveRight = true;
		
	}
	
}