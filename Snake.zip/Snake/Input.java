import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Input extends Main{
	
	public static String focus = "PLAYER";
	
	public static void init(){
		Engine.f.addKeyListener(new KeyListener(){
			@Override
			public void keyPressed(KeyEvent e){
				int key = e.getKeyCode();
				
				if(key == KeyEvent.VK_ESCAPE){
					System.exit(3);
				}
				
				if(key == KeyEvent.VK_SPACE){
					if(FBF){
						System.out.println("\nnext frame:");
						Player.move();
						try{
							Engine.ex.repaint();
						}
						catch(java.util.ConcurrentModificationException CMEX){
							System.out.println("Modification");
						}
					}
				}
				
				if(focus == "PLAYER" && !AI){
					
					//left
					if(key == KeyEvent.VK_A){
						if(!Player.Dir.equals("right")){
							for(Point p : Player.snake){
								if(p.equals(new Point(Player.x - 1, Player.y))){
									return;
								}
							}
							Player.Dir = "left";
						}
					}
					
					//up
					if(key == KeyEvent.VK_W){
						if(!Player.Dir.equals("down")){
							for(Point p : Player.snake){
								if(p.equals(new Point(Player.x, Player.y - 1))){
									return;
								}
							}
							Player.Dir = "up";
						}
					}
					
					//right
					if(key == KeyEvent.VK_D){
						if(!Player.Dir.equals("left")){
							for(Point p : Player.snake){
								if(p.equals(new Point(Player.x + 1, Player.y))){
									return;
								}
							}
							Player.Dir = "right";
						}
					}
					
					//down
					if(key == KeyEvent.VK_S){
						if(!Player.Dir.equals("up")){
							for(Point p : Player.snake){
								if(p.equals(new Point(Player.x, Player.y + 1))){
									return;
								}
							}
							Player.Dir = "down";
						}
					}
					
					if(key == KeyEvent.VK_UP){
						Main.framerate++;
					}
					if(key == KeyEvent.VK_DOWN){
						if(framerate > 1){
							Main.framerate--;
						}
					}
					
				}
				
			}
			@Override
			public void keyReleased(KeyEvent e){
				int key = e.getKeyCode();
				
				/*
				if(key == KeyEvent.VK_W){
					Player.up = false;
				}
				if(key == KeyEvent.VK_S){
					Player.down = false;
				}
				if(key == KeyEvent.VK_A){
					Player.left = false;
				}
				if(key == KeyEvent.VK_D){
					Player.right = false;
				}
				*/
				
			}
			@Override
			public void keyTyped(KeyEvent e){
				int key = e.getKeyCode();
				
			}
		});
		
	}
}