import java.awt.*;
import javax.swing.*;

public class Main extends JPanel{
	
	public static Integer framerate = 10;
	
	public static Integer frame = 0;
	
	public static boolean isBet(int num, int start, int stop){
		//System.out.println(start + ", " + num + ", " + stop + ", " + (num >= start && num <= stop));
		return num >= start && num <= stop;
	}
	
	public static boolean isBet(double num, double start, double stop){
		//System.out.println(start + ", " + num + ", " + stop + ", " + (num >= start && num <= stop));
		return num >= start && num <= stop;
	}
	
	public static Integer dif(int x, int y){
		return Math.abs(x - y);
	}
	
	public static Boolean FBF = false;
	
	public static Boolean AI = false;
	
	public static void main(String[] args){
		
		System.out.println("STARTING...");
		
		Input.init();
		
		Engine.init();
		
		Player.init();
		
		System.out.println("STARTED\n|");
		
		while(!FBF){
			try{Thread.sleep(1000/framerate);} catch(InterruptedException e){}
			
			Player.move();
			
			try{
				Engine.ex.repaint();
			}
			catch(java.util.ConcurrentModificationException e){
				System.out.println("Modification");
			}
			
		}
	}
}