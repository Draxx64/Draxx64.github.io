import java.awt.*;
import javax.swing.*;

public class Engine extends Main{
	
	//40 x 24
	public static Integer screenWidth = 512*2;
	public static Integer screenHeight = 512 + 32 - 1;
	
	public static String out = "";
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setFont(new Font("MONOSPACED", Font.BOLD, 14));
		
		g.translate(512, 0);
		
		g.setColor(new Color(0, 0, 0));
		g.fillRect(-512, 0, screenWidth, screenHeight);
		g.setColor(new Color(255, 255, 255));
		
		for(int x = 0 ; x < 516 ; x++){
			for(int y = 0 ; y < 516 ; y++){
				g.drawRect(x * 16, y * 16, 16, 16);
			}
		}
		
		g.drawRect(-511, 99, 33, 33);
		
		Player.drawSnake(g);
		
		Player.drawItem(g);
		g.setColor(new Color(0, 0, 255));
		g.setColor(new Color(255, 255, 255));
		g.drawString(out, -512, 14);
		g.drawString("Starting size: " + Integer.toString(Player.startSize), -512, 14*2);
		g.drawString("Snake size: " + Integer.toString(Player.snake.size()), -512, 14*3);
		g.drawString("Items got: " + Integer.toString(Player.snake.size() - Player.startSize), -512, 14*4);
		g.drawString("Deaths: " + Integer.toString(Player.deaths), -512, 14*5);
		g.drawString("Position: " + Integer.toString(Player.x) + ", " + Integer.toString(Player.y), -512, 14*6);
		
	}
	
	static JFrame f = new JFrame("Snake");
	static JPanel p = new JPanel();
	
	static Engine ex = new Engine();
	static Engine console = new Engine();
	
	public static void init(){
		
		f.dispose();
		f.add(ex);
		
		p.setFocusable(true);
		p.requestFocusInWindow();
		f.setSize(new Dimension(screenWidth, screenHeight));
		f.setResizable(true);
		f.setVisible(true);
		f.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	}
}