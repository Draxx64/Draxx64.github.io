import java.awt.*;
import javax.swing.*;
import java.util.Random;
import java.util.ArrayList;

public class Player extends Main{
	
	public static Boolean start = true;
	
	public static Random rand = new Random();
	
	public static Integer startSize = 5;
	public static Integer deaths = 0;
	public static Boolean addTail = false;
	
	public static void init(){
		
		snake.clear();
		
		startSize--;
		
		x = 16;
		y = 16;
		
		switch(rand.nextInt(4)){
			case 0:
				Dir = "left";
				break;
			case 1:
				Dir = "right";
				break;
			case 2:
				Dir = "up";
				break;
			case 3:
				Dir = "down";
				break;
		}
		
		snake.add(new Point(x, y));
		switch(Dir){
			case "left":
				for(int i = 0 ; i < startSize ; i++){
					snake.add(new Point(x+i, y));
				}
				break;
			case "up":
				for(int i = 0 ; i < startSize ; i++){
					snake.add(new Point(x, y+i));
				}
				break;
			case "right":
				for(int i = 0 ; i < startSize ; i++){
					snake.add(new Point(x-i, y));
				}
				break;
			case "down":
				for(int i = 0 ; i < startSize ; i++){
					snake.add(new Point(x, y-i));
				}
				break;
			
		}
		startSize++;
		genItem();
	}
	
	public static String Dir;
	
	public static ArrayList<Point> snake = new ArrayList<>();
	
	public static Integer x = 0;
	public static Integer y = 0;
	
	//left = x-
	//right = x+
	//up = y-
	//down = y+
	public static void move(){
		if(AI){
			// https://www.youtube.com/watch?v=AByj76WhRuY
			/*
			if(!Player.Dir.equals("right")){
				for(Point p : Player.snake){
					if(p.equals(new Point(Player.x - 1, Player.y))){
						return;
					}
				}
				Player.Dir = "left";
			}
			*/
			//left
			if(item.x < snake.get(0).x && Math.abs(item.x - snake.get(0).x) > Math.abs(item.y - snake.get(0).y)){
				if(Player.Dir.equals("right")){
					Dir = "down";
					for(Point p : Player.snake){
						if(p.equals(new Point(Player.x - 1, Player.y))){
							return;
						}
					}
				}
				else{
					Player.Dir = "left";
				}
			}
			
			//up
			if(item.y < snake.get(0).y && Math.abs(item.y - snake.get(0).y) > Math.abs(item.x - snake.get(0).x)){
				if(Player.Dir.equals("down")){
					Dir = "right";
					for(Point p : Player.snake){
						if(p.equals(new Point(Player.x, Player.y - 1))){
							return;
						}
					}
				}
				else{
					Player.Dir = "up";
				}
			}
			
			//right
			if(item.x > snake.get(0).x && Math.abs(item.x - snake.get(0).x) > Math.abs(item.y - snake.get(0).y)){
				if(Player.Dir.equals("left")){
					Dir = "up";
					for(Point p : Player.snake){
						if(p.equals(new Point(Player.x + 1, Player.y))){
							return;
						}
					}
				}
				else{
					Player.Dir = "right";
				}
			}
			
			//down
			if(item.y > snake.get(0).y && Math.abs(item.y - snake.get(0).y) > Math.abs(item.x - snake.get(0).x)){
				if(Player.Dir.equals("up")){
					Dir = "right";
					for(Point p : Player.snake){
						if(p.equals(new Point(Player.x, Player.y + 1))){
							return;
						}
					}
				}
				else{
					Player.Dir = "down";
				}
			}
			
		}
			
		for(int i = snake.size() - 1; i > 0 ; i--){
			snake.set(i, snake.get(i - 1));
			if(i == snake.size() - 1){
				if(addTail){
					snake.add(snake.get(i));
					addTail = false;
				}
			}
		}
		switch(Dir){
			case "left":
				x--;
				break;
			case "up":
				y--;
				break;
			case "right":
				x++;
				break;
			case "down":
				y++;
				break;
			
		}
		snake.set(0, new Point(x, y));
		int head = 0;
		for(Point p : snake){
			if(snake.get(0).x == p.x && snake.get(0).y == p.y){
				head++;
			}
		}
		if(snake.get(0).x < 0 || snake.get(0).x > 31 || snake.get(0).y < 0 || snake.get(0).y > 31){
			head += 2;
		}
		if(head > 1){
			init();
			deaths++;
		}
		if(snake.get(0).equals(item)){
			genItem();
			addTail = true;
		}
		Engine.out = Dir;
	}
	
	public static void drawSnake(Graphics g){
		for(Point p : snake){
			g.fillRect(p.x*16, p.y*16, 16, 16);
			g.fillRect(p.x - 510, p.y + 100, 1, 1);
		}
	}
	
	public static Point item;
	
	public static void genItem(){
		loop:
		while(true){
			item = new Point(rand.nextInt(22) + 5, rand.nextInt(22) + 5);
			for(Point p : snake){
				if(item.equals(p)){
					continue loop;
				}
			}
			break;
		}
	}
	
	public static void drawItem(Graphics g){
		g.setColor(new Color(255, 0, 0));
		g.fillRect(item.x*16, item.y*16, 16, 16);
		g.fillRect(item.x - 510, item.y + 100, 1, 1);
	}
	
}