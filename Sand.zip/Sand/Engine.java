import java.awt.*;
import javax.swing.*;

public class Engine extends Main{
	public static Integer screenWidth = 1280;
	public static Integer screenHeight = 720;
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		g.setColor(new Color(0, 0, 0, 255));
		g.fillRect(0, 0, screenWidth, screenHeight);
		for(int x = 0 ; x < Engine.screenWidth ; x += 16){
			for(int y = 0 ; y < Engine.screenHeight ; y += 16){
				g.drawRect(x, y, 16, 16);
			}	
		}
		g.setColor(new Color(255, 255, 255, 255));
		
		Sand.drawSand(g);
		
	}
	
	static JFrame f = new JFrame("Sand");
	static JPanel p = new JPanel();
	
	static Engine ex = new Engine();
	
	public static void init(){
		f.dispose();
		f.add(ex);
		
		p.setFocusable(true);
		p.requestFocusInWindow();
		f.setSize(new Dimension(screenWidth, screenHeight + 25));
		f.setVisible(true);
	}
}