public class Init extends Main{
	
	public static void init(){
		System.out.println("ENGINE");
		Engine.init();
		
		System.out.println("DONE\n|");
	}
}