import java.awt.*;
import javax.swing.*;
import java.util.Random;

public class Main extends JPanel{
	
	public static Integer fps = 10;
	public static Integer wfps = 1000/fps;
	
	public static void main(String[] args){
		System.out.println("SAND START");
		Init.init();
		while(true){
			try{Thread.sleep(wfps);} catch(InterruptedException e){}
			Engine.ex.repaint();
			
			Sand.makeSand();
			Sand.makeSand();
			Sand.makeSand();
			
			Sand.updateSand();
		}
	}
}