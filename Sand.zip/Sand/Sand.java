import java.awt.*;
import javax.swing.*;
import java.util.Random;
import java.util.ArrayList;

public class Sand extends Main{
	
	public static Random rando = new Random();
	
	public static boolean[][] Grid = new boolean[80][45];
	public static boolean[][] moved = new boolean[80][45];
	
	public static Integer rand(int n){
		return rando.nextInt(n);
	}
	
	public static void makeSand(){
		int x = rand(79) + 1;
		int y = 1;
		
		while(true){
			if(!Grid[x][y]){
				Grid[x][y] = true;
				break;
			}
			else{
				x = rand(79) + 1;
				y = 1;
				continue;
			}
		}
	}
	
	public static void updateSand(){
		for(int x = 1 ; x < 79 ; x++){
			for(int y = 1 ; y < 44 ; y++){
				if(Grid[x][y] && !Grid[x][y + 1] && !moved[x][y]){
					Grid[x][y + 1] = true;
					Grid[x][y] = false;
					moved[x][y + 1] = true;
				}
				else{
					switch(rand(2)){
						case 0:
							if(Grid[x][y] && !Grid[x + 1][y + 1] && !moved[x][y]){
								Grid[x + 1][y + 1] = true;
								Grid[x][y] = false;
								moved[x + 1][y + 1] = true;
							}
							if(Grid[x][y] && !Grid[x - 1][y + 1] && !moved[x][y]){
								Grid[x - 1][y + 1] = true;
								Grid[x][y] = false;
								moved[x - 1][y + 1] = true;
							}
							break;
							
						case 1:
							if(Grid[x][y] && !Grid[x - 1][y + 1] && !moved[x][y]){
								Grid[x - 1][y + 1] = true;
								Grid[x][y] = false;
								moved[x - 1][y + 1] = true;
							}
							if(Grid[x][y] && !Grid[x + 1][y + 1] && !moved[x][y]){
								Grid[x + 1][y + 1] = true;
								Grid[x][y] = false;
								moved[x + 1][y + 1] = true;
							}
							break;
					}
				}
			}
		}
		moved = new boolean[80][45];
	}
		
	public static void drawSand(Graphics g){
		for(int x = 0 ; x < 80 ; x++){
			for(int y = 0 ; y < 45 ; y++){
				if(Grid[x][y]){
					g.fillRect(x*16, y*16, 16, 16);
				}
			}
		}
	}
}