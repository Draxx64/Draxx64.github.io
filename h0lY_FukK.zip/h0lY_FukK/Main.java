import java.awt.*;
import javax.swing.*;

public class Main extends JPanel{
	
	public static Integer frame = 0;
	
	public static String getFilePath(String str){
		return ClassLoader.getSystemResource("").getPath().split(".bin/")[0] + str;
	}
	
	public static void main(String[] args){
		System.out.println("STARTING...");
		
		Engine.makeImage();
		
		Engine.init();
		
		Mini.init();
		
		Console.init();
		
		Input.init();
		
		System.out.println("STARTED\n|");
		
		while(true){
			try{
				Engine.ex.repaint();
				Mini.ex.repaint();
				Console.ex.repaint();
			}
			catch(java.util.ConcurrentModificationException e){
				System.out.println("Modification");
			}
			
			try{Thread.sleep(1000/10);} catch(InterruptedException e){}
		}
	}
}