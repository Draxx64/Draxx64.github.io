import java.awt.*;
import javax.swing.*;

public class Console extends Main{
	
	public static Integer screenWidth = 255;
	public static Integer screenHeight = 255 + 32 + 2;
	
	public static Integer TimesSave = 0;
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setFont(new Font("MONOSPACED", Font.BOLD, 14));
		
		g.drawString("x offset:" + String.valueOf(Engine.xoff), 0, 14*1);
		g.drawString("y offset:" + String.valueOf(Engine.yoff), 0, 14*2);
		g.drawString("image scale:" + String.valueOf(Engine.scale), 0, 14*3);
		g.drawString("colors shown:", 0, 14*4);
		String show = "";
		if(Engine.showR) show += "R ";
		else show += "  ";
		if(Engine.showG) show += "G ";
		else show += "  ";
		if(Engine.showB) show += "B ";
		else show += "  ";
		g.drawString(show, 0, 14*5);
		//a = 14*x ^^^up there^^^
		int a = 5;
		g.drawString("image saved: " + String.valueOf(Input.saved), 0, 14*(a + 2));
		g.drawString("times saved: " + String.valueOf(TimesSave), 0, 14*(a + 3));
		
		g.drawString("Controls: ", 0, 14*(a + 5));
		g.drawString("Space saves image", 0, 14*(a + 6));
		g.drawString("Arrows move \"camera\"", 0, 14*(a + 7));
		g.drawString("W and S change image scale", 0, 14*(a + 8));
		g.drawString("I, O, and P toggle colors", 0, 14*(a + 9));
		g.drawString("R reloads image", 0, 14*(a + 10));
		
		
	}
	
	static JFrame f = new JFrame("CONSOLE");
	static JPanel p = new JPanel();
	
	static Console ex = new Console();
	
	public static void init(){
		
		f.dispose();
		f.add(ex);
		
		p.setFocusable(true);
		p.requestFocusInWindow();
		f.setSize(new Dimension(screenWidth, screenHeight));
		f.setResizable(true);
		f.setVisible(true);
		f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		f.setLocation(Engine.screenWidth + 255, 0);
	}
}
