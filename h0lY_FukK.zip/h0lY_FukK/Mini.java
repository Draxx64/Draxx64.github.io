import java.awt.*;
import javax.swing.*;

public class Mini extends Main{
	
	public static Integer screenWidth = 255;
	public static Integer screenHeight = 255 + 32 + 2;
	
	@Override
	public void paintComponent(Graphics gnot){
		super.paintComponent(gnot);
		Graphics2D g = (Graphics2D) gnot;
		g.setFont(new Font("MONOSPACED", Font.BOLD, 14));
		
		g.setColor(new Color(0, 0, 0));
		g.fillRect(0, 0, 255, 255);
		
		g.scale(1/Engine.scale, 1/Engine.scale);
		
		g.setColor(new Color(255, 255, 255));
		Dimension r = Engine.f.getSize();
		Integer h = r.height;
		Integer w = r.width;
		Double xoff = 0D;
		Double yoff = 0D;
		if(Input.MouseDown){
			xoff = (Engine.xoff/3D) - (Engine.nxoff/3D);
			yoff = (Engine.yoff/3D) - (Engine.nyoff/3D);
		}
		else{
			xoff = Engine.xoff/3D;
			yoff = Engine.yoff/3D;
		}
		g.drawRect(-(xoff.intValue()), -(yoff.intValue()), ((Double) (w/3D)).intValue(), ((Double) (h/3D)).intValue());
		
	}
	
	static JFrame f = new JFrame("MiniMap");
	static JPanel p = new JPanel();
	
	static Mini ex = new Mini();
	
	public static void init(){
		
		f.dispose();
		f.add(ex);
		
		p.setFocusable(true);
		p.requestFocusInWindow();
		f.setSize(new Dimension(screenWidth, screenHeight));
		f.setResizable(true);
		f.setVisible(true);
		f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		f.setLocation(Engine.screenWidth, 0);
	}
}
