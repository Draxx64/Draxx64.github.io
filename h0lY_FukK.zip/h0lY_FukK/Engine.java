import java.awt.*;
import javax.swing.*;

import java.io.*;
import java.awt.image.BufferedImage;
import javax.imageio.*;

public class Engine extends Main{
	
	public static Integer screenWidth = 255*3;
	public static Integer screenHeight = 255*3;
	
	//screen control variables
	public static Integer xoff = 0;
	public static Integer yoff = 0;
	public static Double scale = 1D;
	public static Boolean showR = true;
	public static Boolean showG = true;
	public static Boolean showB = true;
	
	public static BufferedImage img = new BufferedImage(screenWidth, screenHeight, BufferedImage.TYPE_INT_RGB);
	public static Graphics g = img.createGraphics();
	public static Image actual_img = new ImageIcon(ClassLoader.getSystemResource("").getPath().split(".bin/")[0] + "Temp/Pic.png").getImage();
		
	public static Point getMouse(){
		Point m = new Point(MouseInfo.getPointerInfo().getLocation());
		Point s = new Point(f.getLocationOnScreen());
		
		return new Point(m.x - s.x, (m.y - s.y) - 34);
	}
	
	public static void makeImage(){
		
		Double red = 0D;
		Double gre = 0D;
		Double blu = 0D;
		
		for(Double x = 1D; x < screenWidth; x++){
			for(Double y = 1D; y < screenHeight; y++){
				
				//MARKED START
				//~>>
				red = Math.sqrt(Math.pow(y, x/y)) * x * y;
				blu = Math.sqrt(Math.pow(x, y/x)) * y * x;
				gre = Math.sqrt(x*y) * y * x;
				//<<~
				//MARKED END
				
				red %= 255;
				gre %= 255;
				blu %= 255;
				
				/*
				red = Math.abs(red);
				gre = Math.abs(red);
				blu = Math.abs(gre);
				*/
				
				if(!showR) red = 0D;
				if(!showG) gre = 0D;
				if(!showB) blu = 0D;
				
				try{
					g.setColor(new Color(red.intValue(), gre.intValue(), blu.intValue()));
				}
				catch(IllegalArgumentException IAEX){
					System.out.println("\nbroke:");
					System.out.println("X: " + x + ", Y: " + y);
					System.out.println("red: " + red);
					System.out.println("gre: " + gre);
					System.out.println("blu: " + blu);
					System.exit(1);
				}
				g.fillRect(x.intValue(), y.intValue(), 1, 1);
			}
		}
		
		new File(getFilePath("Temp/")).mkdir();
		
		int num = 0;
		File outputfile = new File(getFilePath("Temp/Pic.png"));
		try{
			ImageIO.write(img, "png", outputfile);
		}
		catch(IOException IOEX){
			IOEX.printStackTrace();
		}
		
		actual_img = (Image) img;
		
	}
	
	public static Integer nxoff = 0;
	public static Integer nyoff = 0;
	
	@Override
	public void paintComponent(Graphics gnot){
		super.paintComponent(gnot);
		Graphics2D g = (Graphics2D) gnot;
		g.setFont(new Font("MONOSPACED", Font.BOLD, 14));
		
		if(Input.MouseDown){
			nxoff = Input.MouseStart.x - Engine.getMouse().x;
			nyoff = Input.MouseStart.y - Engine.getMouse().y;
			g.translate(xoff - nxoff, yoff - nyoff);
		}
		else g.translate(xoff, yoff);
		
		g.scale(scale, scale);
		
		g.setColor(new Color(0, 0, 0));
		g.fillRect(-51, -51, screenWidth + 102, screenHeight + 102);
		g.setColor(new Color(255, 255, 255));
		g.drawRect(-1, -1, screenWidth + 1, screenHeight + 1);
		
		g.drawImage(actual_img, 0, 0, Engine.f);
		
	}
	
	static JFrame f = new JFrame("h0lY_FukK");
	static JPanel p = new JPanel();
	
	static Engine ex = new Engine();
	
	public static void init(){
		
		f.dispose();
		f.add(ex);
		
		p.setFocusable(true);
		p.requestFocusInWindow();
		f.setSize(new Dimension(screenWidth, screenHeight + 32 + 2));
		f.setResizable(true);
		f.setVisible(true);
		f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
	}
}
