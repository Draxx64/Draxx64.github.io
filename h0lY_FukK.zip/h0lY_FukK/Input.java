import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.io.*;
import java.awt.image.BufferedImage;
import javax.imageio.*;

import java.util.ArrayList;

public class Input extends Main{
	
	public static Boolean saved = false;
	public static Boolean first = true;
	public static Boolean MouseDown = false;
	public static Point MouseStart = new Point();
	
	public static Integer runNum = 0;
	public static Integer picNum = 0;
	public static String filepath = "";
	
	public static void init(){
		Engine.f.addKeyListener(new KeyListener(){
			@Override
			public void keyPressed(KeyEvent e){
				int key = e.getKeyCode();
				
				if(key == KeyEvent.VK_UP){
					Engine.yoff += 51;
				}
				if(key == KeyEvent.VK_DOWN){
					Engine.yoff -= 51;
				}
				if(key == KeyEvent.VK_RIGHT){
					Engine.xoff -= 51;
				}
				if(key == KeyEvent.VK_LEFT){
					Engine.xoff += 51;
				}
				
				if(key == KeyEvent.VK_W){
					Engine.scale += 0.1D;
				}
				if(key == KeyEvent.VK_S){
					Engine.scale -= 0.1D;
				}
				
				if(key == KeyEvent.VK_I){
					Engine.showR = !Engine.showR;
				}
				if(key == KeyEvent.VK_O){
					Engine.showG = !Engine.showG;
				}
				if(key == KeyEvent.VK_P){
					Engine.showB = !Engine.showB;
				}
				
				if(key == KeyEvent.VK_R){
					Engine.makeImage();
				}
				
				if(key == KeyEvent.VK_J){
					Engine.scale = 3.0D;
					Input.MouseDown = false;
					Engine.xoff = -383;
					Engine.yoff = -383;
				}
				if(key == KeyEvent.VK_K){
					Engine.scale = 3.0D;
					Input.MouseDown = false;
					Engine.xoff = 0;
					Engine.yoff = 0;
				}
				if(key == KeyEvent.VK_L){
					Engine.scale = 1.0D;
					Input.MouseDown = false;
					Engine.xoff = 0;
					Engine.yoff = 0;
				}
				
				if(key == KeyEvent.VK_SPACE){
					System.out.println("ATTEMPTING SAVE");
					
					if(!saved){
						filepath = getFilePath("Saved/Run_");
						while(new File(filepath + runNum + "/").exists()){
							runNum++;
						}
						filepath = getFilePath("Saved/Run_" + runNum);
						new File(filepath + "/Pics/").mkdirs();
						new File(filepath + "/Equs/").mkdirs();
						saved = true;
					}
					if(saved){
						File outputfile = new File(filepath + "/Pics/Pic_" + picNum + ".png");
						
						try{
							if(!first){
								BufferedImage newimg = Engine.img.getSubimage(
									-Engine.xoff, -Engine.yoff, 
									(int) (Engine.screenWidth/Engine.scale), 
									(int) (Engine.screenHeight/Engine.scale)
								);
								ImageIO.write(newimg, "png", outputfile);
								System.out.println("Image Saved Successfully");
							}
							if(first){
								BufferedImage newimg = Engine.img.getSubimage(
									-Engine.xoff, -Engine.yoff, 
									(int) (Engine.screenWidth/Engine.scale), 
									(int) (Engine.screenHeight/Engine.scale)
								);
								ImageIO.write(newimg, "png", outputfile);
								System.out.println("Image Saved Successfully");
								
								outputfile = new File(filepath + "/Pics/Pic.png");
								newimg = Engine.img;
								ImageIO.write(newimg, "png", outputfile);
								System.out.println("Image Saved Successfully");
							}
						}
						catch(IOException IOEX){
							System.out.println("Error saving image");
							IOEX.printStackTrace();
							System.exit(1);
						}
					}
					try{
						FileInputStream in = new FileInputStream(new File(getFilePath("Engine.java")));
						FileOutputStream out = new FileOutputStream(new File(filepath + "/Equs/Equ_" + picNum + ".txt"));
						
						outer: while(true){
							//start
							if(in.read() == '~') if(in.read() == '>') if(in.read() == '>') if(in.read() == '\n'){
								if(first){
									out = new FileOutputStream(new File(filepath + "/Equs/Equ.txt"));
									out.write("//~>>\n".getBytes());
									nut: while(true){
										Character ch = (char) in.read();
										if(ch.equals('\t')){
											continue;
										}
										out.write(ch);
										//end
										if(ch == '<') if(in.read() == '<') if(in.read() == '~'){
											out.write("<~".getBytes());
											break nut;
										}
									}
									
									out = new FileOutputStream(new File(filepath + "/Equs/Equ_" + picNum + ".txt"));
									while(true){
										out.write("//showing:\n//".getBytes());
										String show = "";
										if(Engine.showR) show += "R ";
										else show += "  ";
										if(Engine.showG) show += "G ";
										else show += "  ";
										if(Engine.showB) show += "B ";
										else show += "  ";
										out.write(show.getBytes());
										out.write(("\n//zoom: " + Engine.scale).getBytes());
										break outer;
									}
								}
								if(!first){
									out = new FileOutputStream(new File(filepath + "/Equs/Equ_" + picNum + ".txt"));
									while(true){
										Character ch = (char) in.read();
										if(ch.equals('\t')){
											continue;
										}
										if(ch == '<') if(in.read() == '<') if(in.read() == '~'){
											out.write("//showing:\n//".getBytes());
											String show = "";
											if(Engine.showR) show += "R ";
											else show += "  ";
											if(Engine.showG) show += "G ";
											else show += "  ";
											if(Engine.showB) show += "B ";
											else show += "  ";
											out.write(show.getBytes());
											out.write(("\n//zoom: " + Engine.scale).getBytes());
											break outer;
										}
									}
								}
							}
						}
						out.close();
						in.close();
						System.out.println("Equation Saved Successfully");
					}
					catch(IOException IOEX){
						System.out.println("Error saving equation");
						IOEX.printStackTrace();
						System.exit(1);
					}
					System.out.println("SAVED\n");
					Console.TimesSave++;
					picNum++;
					first = false;
				}
				
			}
			@Override
			public void keyReleased(KeyEvent e){
				int key = e.getKeyCode();
				
			}
			@Override
			public void keyTyped(KeyEvent e){
				int key = e.getKeyCode();
				
			}
		});
		
		Engine.f.addMouseListener(new MouseAdapter(){
			@Override
			public void mousePressed(MouseEvent e){
				
				//left click
				if(e.getButton() == MouseEvent.BUTTON1){
					MouseDown = true;
					MouseStart = Engine.getMouse();
				}
				//right click
				if(e.getButton() == MouseEvent.BUTTON3){
				}
				//middle click
				if(e.getButton() == MouseEvent.BUTTON2){
				}
			}
			
			@Override
			public void mouseReleased(MouseEvent e){
				
				//left click
				if(e.getButton() == MouseEvent.BUTTON1){
					MouseDown = false;
					Engine.xoff -= MouseStart.x - Engine.getMouse().x;
					Engine.yoff -= MouseStart.y - Engine.getMouse().y;
				}
				//right click
				if(e.getButton() == MouseEvent.BUTTON3){
				}
				//middle click
				if(e.getButton() == MouseEvent.BUTTON2){
				}
			}
		});
		
	}
}