import java.awt.*;
import javax.swing.*;

import java.net.*;
import java.io.*;

public class Main extends JPanel{
	
	public static ObjectOutputStream writer;
	public static ObjectInputStream reader;
	
	public static Integer framerate = 60;
	public static Integer frame = 0;
	
	public static Integer gamestate = 0;
	
	public static final Boolean online = true;
	public static String wai = "NULL";
	public static Integer wai(){
		if(wai.equals("NULL")) return 0;
		if(wai.equals("SERVER")) return 1;
		if(wai.equals("CLIENT")) return 2;
		System.out.println("wai: " + wai);
		System.exit(9);
		return null;
	}
	
	public static String getFilePath(String str){
		return ClassLoader.getSystemResource("").getPath().split(".bin/")[0] + str;
	}
	
	public static void main(String[] args) throws InterruptedException{
		
		System.out.println("STARTING...");
		
		Engine.init();
		
		System.out.println("STARTED\n|");
		
		while(true){
			Thread.sleep(1000/framerate);
			
			if(!wai.equals("NULL")){
				if(online) Control.check();
				Player.update();
				if(online) Control.FlushWriter();
			}
			
			try{
				Engine.ex.repaint();
			}
			catch(java.util.ConcurrentModificationException e){
				System.out.println("Modification");
			}
			
			frame++;
		}
	}
}