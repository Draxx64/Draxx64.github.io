import java.util.ArrayList;

import java.net.*;
import java.io.*;

public class Control extends Main{
	
	public static ServerSocket serverSocket;
	public static Socket socket;
	
	public static Boolean ready = false;
	
	public static void FlushWriter(){
		try{
			Write(new Info("ENDOBJ", "NULL"));
			writer.flush();
		}
		catch(IOException IOEX){
			System.out.println(wai + " Check Broke: \nIOException");
			IOEX.printStackTrace();
			System.exit(3);
		}
	}
	
	public static void Write(Info inf){
		try{
			writer.writeObject(new Info(inf));
		}
		catch(IOException IOEX){
			System.out.println(wai + " Check Broke: \nIOException");
			IOEX.printStackTrace();
			System.exit(3);
		}
	}
	
	public static Boolean BigDebug = false;
	
	public static void check(){
		if(!ready) return;
		try{
			Info i;
			if(BigDebug) System.out.println("___READING");
			boolean checked = false;
			out: while((i = new Info((Info) reader.readObject())) != null){
				
				if(BigDebug) System.out.println(i.name + ", " + String.valueOf(i.obj));
				
				if(i.name.equals("ENDOBJ")) break out;
				
				String name = i.name;
				Object obj = i.obj;
				
				if(!name.equals("NULL")){
					
					// my position
					if(name.equals("Plx")){
						OtherPlayer.x = (Integer) obj;
					}
					
					if(name.equals("PlHP")){
						OtherPlayer.health = (Integer) obj;
					}
					
					if(name.equals("PlGS")){
						int gs = (Integer) obj;
						if(gs == -1){
							gamestate = 1;
						}
					}
					
					if(name.equals("PlDam")){
						OtherPlayer.damage = (Boolean) obj;
					}
					
					// mai bulless
					if(name.equals("Plb")){
						OtherPlayer.bullets.clear();
						Object[] temp = (Object[]) obj;
						for(Object o : temp){
							Bullet b = (Bullet) o;
							OtherPlayer.bullets.add(b);
						}
					}
					if(name.equals("Plby")){
						Integer[] plby = (Integer[]) obj;
						for(int b = 0; b < OtherPlayer.bullets.size(); b++){
							Bullet t = OtherPlayer.bullets.get(b);
							t.y = Engine.screenHeight - plby[b];
							OtherPlayer.bullets.set(b, t);
						}
					}
					
				}
			}
			if(BigDebug) System.out.println("___END");
		}
		catch(java.net.SocketException SX){
			System.out.println();
			System.out.println(wai + " Check Broke: \nSocketException");
			System.out.println("Most likely someone disconnected.");
			SX.printStackTrace();
			System.exit(3);
		}
		catch(IOException IOEX){
			System.out.println();
			System.out.println(wai + " Check Broke: \nIOException");
			IOEX.printStackTrace();
			System.exit(3);
		}
		catch(ClassNotFoundException CNFEX){
			System.out.println();
			System.out.println(wai + " Check Broke: \nClassNotFoundException");
			CNFEX.printStackTrace();
			System.exit(3);
		}
	}
	
	public static void start(String name){
		try{
			if(name.equals("SERVER")){
				new Control().ServerInit();
			}
			if(name.equals("CLIENT")){
				new Control().ClientInit();
			}
			
			boolean buffered = false;
			
			//out
			System.out.println("Making writer");
			if(buffered) writer = new ObjectOutputStream(new BufferedOutputStream(socket.getOutputStream()));
			if(!buffered) writer = new ObjectOutputStream(socket.getOutputStream());
			
			FlushWriter();
			
			//in
			System.out.println("Writer made, making reader");
			if(buffered) reader = new ObjectInputStream(new BufferedInputStream(socket.getInputStream()));
			if(!buffered) reader = new ObjectInputStream(socket.getInputStream());
			
			System.out.println("Streams created");
			
			ready = true;
			
			wai = name;
			
			System.out.println(wai + " Finished init()");
			
			if(name.equals("CLIENT")){
				Write(new Info("Client Init Obj", 1234));
				Write(new Info("ENDOBJ", "NULL"));
			}
			
		}
		catch(IOException IOEX){
			System.out.println(name + " Broke: \nIOException");
			IOEX.printStackTrace();
			System.exit(3);
		}
	}
	
	public static final Integer port = 5555;
	
	public static void ServerInit(){
		if(!wai.equals("NULL")){
			System.out.println("DOUBLE INIT: SERVER, " + wai);
			System.exit(3);
		}
		System.out.println("I AM THE SERVER");
		try{
			System.out.println("Starting server");
			serverSocket = new ServerSocket(port);
			System.out.println("Waiting for client connection...");
			socket = serverSocket.accept();
			System.out.println("Connected, making streams");
		}
		catch(IOException IOEX){
			System.out.println("Server Broke: \nIOException");
			IOEX.printStackTrace();
			System.exit(3);
		}
	}
	
	public static void ClientInit(){
		if(!wai.equals("NULL")){
			System.out.println("DOUBLE INIT: CLIENT, " + wai);
			System.exit(3);
		}
		System.out.println("I AM THE CLIENT");
		try{
			System.out.println("Starting client");
			System.out.println("Connecting client to server...");
			
			FileInputStream get = new FileInputStream(new File(getFilePath("Address.txt")));
			int max = get.available();
			
			int inner = 0;
			
			String address = "";
			
			for(int i = 0; i < max; i++){
				Character in = (char) get.read();
				address += Character.toString(in);
			}
			System.out.println("connecting to: " + address);
			socket = new Socket(address, port);
			System.out.println("Connected, making streams");
		}
		catch(IOException IOEX){
			System.out.println("Client Broke: \nIOException");
			IOEX.printStackTrace();
			System.exit(3);
		}
	}
	
	static class Info extends Control{
	
		public String name = "NULL";
		public Object obj = new Object();
		
		public Info(Info copy){
			this.name = copy.name;
			this.obj = copy.obj;
		}
		
		public Info(String name, Object obj){
			this.name = name;
			this.obj = obj;
		}
		
		public Info(Object obj){
			this.obj = obj;
		}
		
		public Info(){
			
		}
	}
	
}