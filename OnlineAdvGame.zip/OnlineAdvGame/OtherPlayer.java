import java.awt.*;
import javax.swing.*;

import java.util.ArrayList;

public class OtherPlayer extends Main{
	
	public static ArrayList<Bullet> bullets = new ArrayList<>();
	
	public static Integer x = 0;
	public static Integer health = 40;
	public static Boolean damage = false;
	
	public static void drawOtherPlayer(Graphics2D g){
		if(gamestate == 0) g.setColor(new Color(0, 0, 0));
		if(gamestate == -1) g.setColor(new Color(255, 0, 255));
		if(gamestate == 1) g.setColor(new Color(100, 100, 100));
		if(damage) g.setColor(new Color(255, 0, 0));
		g.fillRect(x + 16, 0, 16, 32);
		g.fillRect(x, 0, 16*3, 16);
		
		for(Bullet b : bullets){
			if(gamestate == 0) g.setColor(new Color(200, 0, 0));
			if(gamestate == -1) g.setColor(new Color(255, 0, 255));
			b.drawBullet(g);
			g.setColor(new Color(0, 0, 0));
		}
	}
	
}