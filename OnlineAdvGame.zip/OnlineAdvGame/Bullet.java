import java.awt.*;
import javax.swing.*;

public class Bullet extends Main{
	
	public Boolean updateB(){
		y -= 8;
		if(y < 0 || y > Engine.screenHeight){
			return true;
		}
		return false;
	}
	
	public void drawBullet(Graphics2D g){
		g.fillRect(x, y, 16, 16);
	}
	
	public Integer x;
	public Integer y;
	
	public Bullet(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	public Bullet(){}
}