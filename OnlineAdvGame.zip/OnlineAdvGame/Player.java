import java.awt.*;
import javax.swing.*;

import java.util.ArrayList;

public class Player extends Main{
	
	public static ArrayList<Bullet> bullets = new ArrayList<>();
	
	public static Integer x = 0;
	public static Integer speed = 4;
	public static Integer dir = 0;
	public static Integer health = 40;
	
	public static Integer resetframe = 0;
	
	public static Boolean damage = false;
	
	public static void update(){
		if(frame > resetframe){
			framerate = 60;
			damage = false;
		}
		x += dir*speed;
		while(x < 0) x++;
		while(x > Engine.screenWidth - 16*4) x--;
		
		ArrayList<Bullet> rem = new ArrayList<>();
		try{
			for(Bullet b : bullets){
				if(b.updateB()){
					rem.add(b);
				}
			}
			bullets.removeAll(rem);
		}
		catch(java.util.ConcurrentModificationException CMEX){
			
		}
		
		for(Bullet b : OtherPlayer.bullets){
			if(b.x + 16 > x && b.x < x + 16*3 && b.y > Engine.screenHeight - 32){
				health--;
				if(gamestate == 0){
					framerate = 20;
					resetframe = frame + 20;
					damage = true;
				}
				if(health <= 0){
					health = 0;
					if(gamestate == 0){
						framerate = 10;
						resetframe = frame + 20;
					}
					gamestate = -1;
				}
			}
		}
		
		if(online){
			Control.Write(new Control.Info("Plx", x));
			Control.Write(new Control.Info("Plb", bullets.toArray()));
			Integer[] Plby = new Integer[bullets.size()];
			for(int i = 0; i < bullets.size(); i++){
				Plby[i] = bullets.get(i).y;
			}
			Control.Write(new Control.Info("Plby", Plby));
			Control.Write(new Control.Info("PlHP", health));
			Control.Write(new Control.Info("PlGS", gamestate));
			Control.Write(new Control.Info("PlDam", damage));
		}
	}
	
	public static void shoot(){
		bullets.add(new Bullet(x + 16, Engine.screenHeight - 32));
	}
	
	public static void drawPlayer(Graphics2D g){
		if(gamestate == 0) g.setColor(new Color(0, 0, 0));
		if(gamestate == 1) g.setColor(new Color(255, 0, 255));
		if(gamestate == -1) g.setColor(new Color(100, 100, 100));
		if(damage) g.setColor(new Color(255, 0, 0));
		g.fillRect(x + 16, Engine.screenHeight - 31, 16, 32);
		g.fillRect(x, Engine.screenHeight - 15, 16*3, 16);
		
		//healthbar
		int scrW = Engine.screenWidth;
		int scrH = Engine.screenHeight;
		
		g.setColor(new Color(200, 0, 0));
		g.fill3DRect(scrW - 16, scrH/2, 16, scrH/2, false);
		
		g.setColor(new Color(0, 255, 0));
		g.fill3DRect(scrW - 16, scrH/2, 16, 
			Math.round(new Float((health/40D)*(scrH/2D))),
		false);
		
		g.setColor(new Color(0, 0, 0));
		g.drawString(String.valueOf(health), scrW - 20,
			scrH/2 + Math.round(new Float((health/40D)*(scrH/2D)))
		);
		
		for(Bullet b : bullets){
			if(gamestate == 0) g.setColor(new Color(0, 0, 200));
			if(gamestate == 1) g.setColor(new Color(255, 0, 255));
			b.drawBullet(g);
			g.setColor(new Color(0, 0, 0));
		}
	}	

}