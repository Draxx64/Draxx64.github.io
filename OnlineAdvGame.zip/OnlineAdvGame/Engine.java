import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Engine extends Main{
	
	public static Integer screenWidth = 8*32 + 16;
	public static Integer screenHeight = 8*64;
	
	@Override
	public void paintComponent(Graphics ge){
		super.paintComponent(ge);
		Graphics2D g = (Graphics2D) ge;
		g.setFont(new Font("SERIF", Font.BOLD, 16));
		
		if(gamestate == 0) g.drawString(String.valueOf(frame), 0, 16*3);
		//g.drawLine(0, screenHeight/2, screenWidth, screenHeight/2);
		
		Player.drawPlayer(g);
		OtherPlayer.drawOtherPlayer(g);
		
		if(gamestate != 0) g.setFont(new Font("SERIF", Font.BOLD, 32));
		
		if(gamestate == 1){
			g.setColor(new Color(0, 0, 255));
			g.drawString("YOU WIN!", 64, 64);
		}
		if(gamestate == -1){
			g.setColor(new Color(0, 50, 150));
			g.drawString("you lose...", 64, 64);
		}
		
	}
	
	static JFrame f = new JFrame("Advanced Online Game");
	static JPanel p = new JPanel();
	
	static Engine ex = new Engine();
	
	public static void init(){
		
		f.dispose();
		f.add(ex);
		
		p.setFocusable(true);
		p.requestFocusInWindow();
		f.setSize(new Dimension(screenWidth, screenHeight + 33));
		f.setResizable(false);
		f.setVisible(true);
		f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
		
		// init keys
		f.addKeyListener(new KeyListener(){
			@Override
			public void keyPressed(KeyEvent e){
				int key = e.getKeyCode();
				
				if(key == KeyEvent.VK_ESCAPE){
					System.exit(3);
				}
				if(!wai.equals("NULL")){
					
					if(gamestate != -1){
						if(key == KeyEvent.VK_LEFT || key == KeyEvent.VK_A){
							Player.dir = -1;
						}
						if(key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D){
							Player.dir = 1;
						}
						if(key == KeyEvent.VK_SPACE){
							Player.shoot();
						}
					}
					
				}
				if(wai.equals("NULL")){
					if(key == KeyEvent.VK_O){
						f.setLocation(screenWidth, 0);
						Control.start("SERVER");
					}
					if(key == KeyEvent.VK_P){
						Control.start("CLIENT");
					}
				}
				
			}
			@Override
			public void keyReleased(KeyEvent e){
				int key = e.getKeyCode();
				if(key == KeyEvent.VK_LEFT || key == KeyEvent.VK_A){
					if(Player.dir == -1) Player.dir = 0;
				}
				if(key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D){
					if(Player.dir == 1) Player.dir = 0;
				}
			}
			
			@Override public void keyTyped(KeyEvent e){int key = e.getKeyCode();}
			
		});
		
	}
}